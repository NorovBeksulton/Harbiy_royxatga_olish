﻿namespace Kurs_ishi
{
    partial class Chop_etish_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Chop_etish_2));
            this.qrbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.todaylb = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.yoshlb = new System.Windows.Forms.Label();
            this.tellb = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.manzillb = new System.Windows.Forms.Label();
            this.millatlb = new System.Windows.Forms.Label();
            this.jinslb = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.shariflbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.familiyalb = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.ismlb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.qrcodebox = new System.Windows.Forms.PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qrcodebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // qrbtn
            // 
            this.qrbtn.Image = global::Kurs_ishi.Properties.Resources.qr_code__1_;
            this.qrbtn.Location = new System.Drawing.Point(74, -4);
            this.qrbtn.Name = "qrbtn";
            this.qrbtn.Size = new System.Drawing.Size(69, 53);
            this.qrbtn.TabIndex = 2;
            this.qrbtn.UseVisualStyleBackColor = true;
            this.qrbtn.Click += new System.EventHandler(this.qrbtn_Click);
            // 
            // button1
            // 
            this.button1.Image = global::Kurs_ishi.Properties.Resources.printer__1_;
            this.button1.Location = new System.Drawing.Point(3, -4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 53);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.todaylb);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.yoshlb);
            this.panel1.Controls.Add(this.tellb);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.manzillb);
            this.panel1.Controls.Add(this.millatlb);
            this.panel1.Controls.Add(this.jinslb);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.shariflbl);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.familiyalb);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.ismlb);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.qrcodebox);
            this.panel1.Controls.Add(this.guna2PictureBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(945, 1011);
            this.panel1.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(467, 982);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 23);
            this.label6.TabIndex = 61;
            this.label6.Text = "Imzo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(406, 952);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(190, 23);
            this.label7.TabIndex = 40;
            this.label7.Text = "__________________";
            // 
            // todaylb
            // 
            this.todaylb.AutoSize = true;
            this.todaylb.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.todaylb.Location = new System.Drawing.Point(176, 952);
            this.todaylb.Name = "todaylb";
            this.todaylb.Size = new System.Drawing.Size(20, 23);
            this.todaylb.TabIndex = 58;
            this.todaylb.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(32, 952);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 23);
            this.label5.TabIndex = 57;
            this.label5.Text = "Bugungi sana:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(65, 519);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 32);
            this.label3.TabIndex = 55;
            this.label3.Text = "Yoshi:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(65, 551);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 32);
            this.label11.TabIndex = 53;
            this.label11.Text = "Tashxis:";
            // 
            // yoshlb
            // 
            this.yoshlb.AutoSize = true;
            this.yoshlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yoshlb.Location = new System.Drawing.Point(231, 519);
            this.yoshlb.Name = "yoshlb";
            this.yoshlb.Size = new System.Drawing.Size(28, 32);
            this.yoshlb.TabIndex = 52;
            this.yoshlb.Text = "*";
            // 
            // tellb
            // 
            this.tellb.AutoSize = true;
            this.tellb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tellb.Location = new System.Drawing.Point(231, 551);
            this.tellb.Name = "tellb";
            this.tellb.Size = new System.Drawing.Size(28, 32);
            this.tellb.TabIndex = 51;
            this.tellb.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(65, 487);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 32);
            this.label15.TabIndex = 59;
            this.label15.Text = "Sharifi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(65, 454);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 32);
            this.label2.TabIndex = 59;
            this.label2.Text = "Familiyasi:";
            // 
            // manzillb
            // 
            this.manzillb.AutoSize = true;
            this.manzillb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.manzillb.Location = new System.Drawing.Point(231, 616);
            this.manzillb.Name = "manzillb";
            this.manzillb.Size = new System.Drawing.Size(28, 32);
            this.manzillb.TabIndex = 50;
            this.manzillb.Text = "*";
            // 
            // millatlb
            // 
            this.millatlb.AutoSize = true;
            this.millatlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.millatlb.Location = new System.Drawing.Point(231, 648);
            this.millatlb.Name = "millatlb";
            this.millatlb.Size = new System.Drawing.Size(28, 32);
            this.millatlb.TabIndex = 48;
            this.millatlb.Text = "*";
            // 
            // jinslb
            // 
            this.jinslb.AutoSize = true;
            this.jinslb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jinslb.Location = new System.Drawing.Point(231, 583);
            this.jinslb.Name = "jinslb";
            this.jinslb.Size = new System.Drawing.Size(28, 32);
            this.jinslb.TabIndex = 47;
            this.jinslb.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(68, 648);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 32);
            this.label12.TabIndex = 46;
            this.label12.Text = "Unvoni:";
            // 
            // shariflbl
            // 
            this.shariflbl.AutoSize = true;
            this.shariflbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.shariflbl.Location = new System.Drawing.Point(231, 487);
            this.shariflbl.Name = "shariflbl";
            this.shariflbl.Size = new System.Drawing.Size(28, 32);
            this.shariflbl.TabIndex = 43;
            this.shariflbl.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(70, 616);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(160, 32);
            this.label9.TabIndex = 44;
            this.label9.Text = "Xizmat joyi:";
            // 
            // familiyalb
            // 
            this.familiyalb.AutoSize = true;
            this.familiyalb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.familiyalb.Location = new System.Drawing.Point(231, 454);
            this.familiyalb.Name = "familiyalb";
            this.familiyalb.Size = new System.Drawing.Size(28, 32);
            this.familiyalb.TabIndex = 43;
            this.familiyalb.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(68, 583);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 32);
            this.label14.TabIndex = 42;
            this.label14.Text = "Jinsi:";
            // 
            // ismlb
            // 
            this.ismlb.AutoSize = true;
            this.ismlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ismlb.Location = new System.Drawing.Point(231, 422);
            this.ismlb.Name = "ismlb";
            this.ismlb.Size = new System.Drawing.Size(28, 32);
            this.ismlb.TabIndex = 49;
            this.ismlb.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(65, 422);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 32);
            this.label1.TabIndex = 60;
            this.label1.Text = "Ismi:";
            // 
            // qrcodebox
            // 
            this.qrcodebox.Location = new System.Drawing.Point(643, 695);
            this.qrcodebox.Name = "qrcodebox";
            this.qrcodebox.Size = new System.Drawing.Size(278, 289);
            this.qrcodebox.TabIndex = 39;
            this.qrcodebox.TabStop = false;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BorderRadius = 10;
            this.guna2PictureBox1.Image = global::Kurs_ishi.Properties.Resources.user;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(674, 332);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(247, 221);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 38;
            this.guna2PictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(272, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(476, 92);
            this.label4.TabIndex = 37;
            this.label4.Text = "   O\'zbekiston Respublikasi \r\n        Xarbiy Xizmatchisi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(424, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(26, -4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(10, 10);
            this.richTextBox1.TabIndex = 62;
            this.richTextBox1.Text = "";
            // 
            // Chop_etish_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(945, 1050);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.qrbtn);
            this.Controls.Add(this.panel1);
            this.Name = "Chop_etish_2";
            this.Text = "Chop_etish_2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Chop_etish_2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qrcodebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button qrbtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PictureBox qrcodebox;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label todaylb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label yoshlb;
        private System.Windows.Forms.Label tellb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label manzillb;
        private System.Windows.Forms.Label millatlb;
        private System.Windows.Forms.Label jinslb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label familiyalb;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label ismlb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label shariflbl;
    }
}