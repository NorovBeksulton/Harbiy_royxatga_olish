﻿namespace Kurs_ishi
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.kirishbtn = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Paroltxt = new System.Windows.Forms.TextBox();
            this.Logintxt = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.eyebtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.orqabtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.emailbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.parolbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.loginbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.ismbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // kirishbtn
            // 
            this.kirishbtn.BackColor = System.Drawing.Color.SpringGreen;
            this.kirishbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kirishbtn.ForeColor = System.Drawing.Color.Black;
            this.kirishbtn.Location = new System.Drawing.Point(144, 318);
            this.kirishbtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kirishbtn.Name = "kirishbtn";
            this.kirishbtn.Size = new System.Drawing.Size(223, 52);
            this.kirishbtn.TabIndex = 14;
            this.kirishbtn.TabStop = false;
            this.kirishbtn.Text = "Kirish";
            this.kirishbtn.UseVisualStyleBackColor = false;
            this.kirishbtn.Click += new System.EventHandler(this.kirishbtn_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(175, 195);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(159, 20);
            this.linkLabel1.TabIndex = 0;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Parolni unutdingizmi?";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SpringGreen;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(260, 231);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(175, 72);
            this.button2.TabIndex = 4;
            this.button2.TabStop = false;
            this.button2.Text = "Ro\'yxatdan o\'tish";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(76, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 22);
            this.label2.TabIndex = 31;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(76, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 22);
            this.label1.TabIndex = 30;
            this.label1.Text = "Login";
            // 
            // Paroltxt
            // 
            this.Paroltxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Paroltxt.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Paroltxt.Location = new System.Drawing.Point(80, 129);
            this.Paroltxt.Name = "Paroltxt";
            this.Paroltxt.PasswordChar = '●';
            this.Paroltxt.Size = new System.Drawing.Size(355, 30);
            this.Paroltxt.TabIndex = 2;
            this.Paroltxt.TabStop = false;
            this.Paroltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Paroltxt_KeyDown);
            // 
            // Logintxt
            // 
            this.Logintxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Logintxt.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Logintxt.Location = new System.Drawing.Point(80, 55);
            this.Logintxt.Name = "Logintxt";
            this.Logintxt.Size = new System.Drawing.Size(355, 30);
            this.Logintxt.TabIndex = 1;
            this.Logintxt.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.eyebtn);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Paroltxt);
            this.panel1.Controls.Add(this.Logintxt);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(48, 213);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(530, 384);
            this.panel1.TabIndex = 35;
            this.panel1.TabStop = true;
            // 
            // eyebtn
            // 
            this.eyebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eyebtn.Image = ((System.Drawing.Image)(resources.GetObject("eyebtn.Image")));
            this.eyebtn.Location = new System.Drawing.Point(455, 125);
            this.eyebtn.Name = "eyebtn";
            this.eyebtn.Size = new System.Drawing.Size(51, 39);
            this.eyebtn.TabIndex = 0;
            this.eyebtn.TabStop = false;
            this.eyebtn.UseVisualStyleBackColor = true;
            this.eyebtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseDown);
            this.eyebtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseUp);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SpringGreen;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(77, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 72);
            this.button1.TabIndex = 3;
            this.button1.TabStop = false;
            this.button1.Text = "Kirish";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // orqabtn
            // 
            this.orqabtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.orqabtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orqabtn.Location = new System.Drawing.Point(0, 0);
            this.orqabtn.Name = "orqabtn";
            this.orqabtn.Size = new System.Drawing.Size(42, 41);
            this.orqabtn.TabIndex = 15;
            this.orqabtn.TabStop = false;
            this.orqabtn.Text = "↩";
            this.orqabtn.UseVisualStyleBackColor = true;
            this.orqabtn.Visible = false;
            this.orqabtn.Click += new System.EventHandler(this.orqabtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(96, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(391, 64);
            this.label7.TabIndex = 2;
            this.label7.Text = "       O\'zbekiston Respublikasi \r\n     Qurolli kuchlari boshqarmasi\r\n";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.emailbox);
            this.panel3.Controls.Add(this.parolbox);
            this.panel3.Controls.Add(this.loginbox);
            this.panel3.Controls.Add(this.ismbox);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.kirishbtn);
            this.panel3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panel3.Location = new System.Drawing.Point(45, 216);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(533, 384);
            this.panel3.TabIndex = 0;
            // 
            // emailbox
            // 
            this.emailbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailbox.DefaultText = "";
            this.emailbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.emailbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.emailbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.emailbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.emailbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.emailbox.Location = new System.Drawing.Point(78, 234);
            this.emailbox.Margin = new System.Windows.Forms.Padding(5);
            this.emailbox.Name = "emailbox";
            this.emailbox.PasswordChar = '\0';
            this.emailbox.PlaceholderText = "Emaillingiz...";
            this.emailbox.SelectedText = "";
            this.emailbox.Size = new System.Drawing.Size(395, 44);
            this.emailbox.TabIndex = 13;
            // 
            // parolbox
            // 
            this.parolbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.parolbox.DefaultText = "";
            this.parolbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.parolbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.parolbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.parolbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.parolbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.parolbox.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.parolbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.parolbox.Location = new System.Drawing.Point(78, 168);
            this.parolbox.Margin = new System.Windows.Forms.Padding(5);
            this.parolbox.Name = "parolbox";
            this.parolbox.PasswordChar = '●';
            this.parolbox.PlaceholderText = "Parollingiz...";
            this.parolbox.SelectedText = "";
            this.parolbox.Size = new System.Drawing.Size(395, 44);
            this.parolbox.TabIndex = 12;
            // 
            // loginbox
            // 
            this.loginbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.loginbox.DefaultText = "";
            this.loginbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.loginbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.loginbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.loginbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.loginbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.loginbox.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loginbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.loginbox.Location = new System.Drawing.Point(78, 106);
            this.loginbox.Margin = new System.Windows.Forms.Padding(5);
            this.loginbox.Name = "loginbox";
            this.loginbox.PasswordChar = '\0';
            this.loginbox.PlaceholderText = "Loginingiz...";
            this.loginbox.SelectedText = "";
            this.loginbox.Size = new System.Drawing.Size(395, 44);
            this.loginbox.TabIndex = 11;
            // 
            // ismbox
            // 
            this.ismbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ismbox.DefaultText = "";
            this.ismbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ismbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ismbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ismbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ismbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ismbox.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ismbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ismbox.Location = new System.Drawing.Point(78, 34);
            this.ismbox.Margin = new System.Windows.Forms.Padding(5);
            this.ismbox.Name = "ismbox";
            this.ismbox.PasswordChar = '\0';
            this.ismbox.PlaceholderText = "Ismingiz...";
            this.ismbox.SelectedText = "";
            this.ismbox.Size = new System.Drawing.Size(395, 44);
            this.ismbox.TabIndex = 10;
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(477, 173);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(51, 39);
            this.button3.TabIndex = 5;
            this.button3.TabStop = false;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
            this.button3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button3_MouseUp);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Info;
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.guna2Button1);
            this.panel2.Controls.Add(this.orqabtn);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 686);
            this.panel2.TabIndex = 2;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 5;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Red;
            this.guna2Button1.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Image = global::Kurs_ishi.Properties.Resources.delete;
            this.guna2Button1.Location = new System.Drawing.Point(559, 0);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(41, 41);
            this.guna2Button1.TabIndex = 3;
            this.guna2Button1.TabStop = false;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(251, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 686);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button kirishbtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button eyebtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox Paroltxt;
        private System.Windows.Forms.TextBox Logintxt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Button orqabtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2TextBox emailbox;
        private Guna.UI2.WinForms.Guna2TextBox parolbox;
        private Guna.UI2.WinForms.Guna2TextBox loginbox;
        private Guna.UI2.WinForms.Guna2TextBox ismbox;
    }
}