﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Kurs_ishi
{
    public partial class Forgotpasword : Form
    {
        public Forgotpasword()
        {
            InitializeComponent();
        }
        Form1 Login;
        SqlConnection con;
        private void parolbtn_Click(object sender, EventArgs e)
        {
           
            if (Paroltxt.Text == string.Empty)
            {
                MessageBox.Show("Iltimos Emailni kiriting", "Ma'lmot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                
                    SqlDataAdapter da = new SqlDataAdapter(
                    "select count(*) from Login where Email='" + Paroltxt.Text + "'", con);
                    DataTable dat = new DataTable();
                    da.Fill(dat);
                    if (dat.Rows[0][0].ToString() == "1")
                    {
                    panel2.Visible = true;
                    panel1.Visible = false;
                    SqlCommand command1 = new SqlCommand("select * from Login where Email='" + Paroltxt.Text + "'", con);

                        var result = command1.ExecuteScalar();

                        int id = Convert.ToInt32(result);
                        query = $"SELECT * FROM Login WHERE id = {id}";
                        using (SqlCommand command = new SqlCommand(query, con))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                reader.Read();
                                panel2.Visible = true;
                                panel1.Visible = false;

                                textBox1.Text = reader[2].ToString();
                                textBox2.Text = reader[3].ToString();
                                textBox3.Text = reader[1].ToString();
                                textBox4.Text = reader[4].ToString();

                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Bunday Email mavjud emas! \nIltimos boshidan kiriting!","Ma'lumot",MessageBoxButtons.OK,MessageBoxIcon.Error);   
                        Paroltxt.Clear();
                    }
              
            }
        }
       
        private void Forgotpasword_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kurs"].ConnectionString);

            con.Open();

        }
        string query;
        private void yangitbn_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Ma'lumotlarni to'liq kiriting");
            }
            else
            {
                SqlCommand command1 = new SqlCommand("select * from Login where Email='" + Paroltxt.Text + "'", con);

                var result = command1.ExecuteScalar();

                int Id = Convert.ToInt32(result);
                SqlCommand cmd = new SqlCommand($"update Login set Ism=@Ism,Login=@Login,Parol=@Parol,Email=@Email where Id={Id}", con);
                cmd.Parameters.AddWithValue("Ism", textBox3.Text);
                cmd.Parameters.AddWithValue("Login", textBox1.Text);
                cmd.Parameters.AddWithValue("Parol", textBox2.Text);
                cmd.Parameters.AddWithValue("Email", textBox4.Text);

                cmd.ExecuteNonQuery().ToString();

                MessageBox.Show("Login va parollingiz o'zgartirildi!");
                Login = new Form1();
                Login.Show();
                Close();
            }
            
        }

        private void eyebtn_MouseDown(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '\0';
        }

        private void eyebtn_MouseUp(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void Paroltxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                panel2.Visible = true;
                panel1.Visible = false;
                if (Paroltxt.Text == string.Empty)
                {
                    MessageBox.Show("Iltimos Email kiriting", "Ma'lmot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    try
                    {
                        SqlCommand command1 = new SqlCommand("select * from Login where Email='" + Paroltxt.Text + "'", con);

                        var result = command1.ExecuteScalar();

                        int id = Convert.ToInt32(result);
                        query = $"SELECT * FROM Login WHERE id = {id}";
                        using (SqlCommand command = new SqlCommand(query, con))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                reader.Read();
                                panel2.Visible = true;
                                panel1.Visible = false;

                                textBox1.Text = reader[2].ToString();
                                textBox2.Text = reader[3].ToString();
                                textBox3.Text = reader[1].ToString();
                                textBox4.Text = reader[4].ToString();

                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Emailni to'g'ri kiriting!");
                    }
                }
            }
        }
       
        private void orqabtn_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
