﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Controls;
using System.Windows.Forms;
using Panel = System.Windows.Forms.Panel;

namespace Kurs_ishi
{
    public partial class Chop_etish : Form
    {
        private Bitmap bp;
        public string Ismi, Familiya,Yoshi,Kasbi,Jinsi,Millati,Manzili,Telefon,Email;

        private void qrbtn_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "Ismi: " + ismlb.Text + "\n" + "Familiyasi: " + familiyalb.Text + "\n" + "Yoshi: " + yoshlb.Text + "\n" + "Jinsi: " + jinslb.Text + "\n" + "Manzili: " + manzillb.Text + "\n" + "Telefon: " + tellb.Text + "\n" + "Emaili: " + emaillb.Text;

            QRCoder.QRCodeGenerator qr = new QRCoder.QRCodeGenerator();
            var qrdata = qr.CreateQrCode(richTextBox1.Text, QRCoder.QRCodeGenerator.ECCLevel.Q);
            var qrcode = new QRCoder.QRCode(qrdata);

            qrcodebox.Image = qrcode.GetGraphic(3);
            button1.Enabled = true;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle rectangle = e.PageBounds;
            e.Graphics.DrawImage(bp, rectangle.Width / 2 - this.guna2Panel1.Width / 4, this.guna2Panel1.Location.Y + 10);
        }

        public System.Drawing.Image Img;
        private void button1_Click(object sender, EventArgs e)
        {
            Print(guna2Panel1);
            button1.Enabled=false;
        }
        private void Print(Panel panel)
        {
            PrinterSettings ps = new PrinterSettings();
            guna2Panel1 = (Guna.UI2.WinForms.Guna2Panel)panel;
            getprintarea(panel);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();

        }
        private void getprintarea(Panel panel)
        {
            bp = new Bitmap(panel.Width, panel.Height);
            panel.DrawToBitmap(bp, new Rectangle(0, 0, guna2Panel1.Width, guna2Panel1.Height));
        }
        private void Chop_etish_Load(object sender, EventArgs e)
        {
            ismlb.Text = Ismi;
            familiyalb.Text = Familiya;
            yoshlb.Text = Yoshi;
            kasblb.Text = Kasbi;
            jinslb.Text = Jinsi;
            millatlb.Text = Millati;
            manzillb.Text = Manzili;
            tellb.Text = Telefon;
            emaillb.Text = Email;
            guna2PictureBox1.Image = Img;
           
            todaylb.Text = DateTime.Now.ToString("MM/dd/yyyy"); ;
            button1.Enabled = false;
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public Chop_etish()
        {
            InitializeComponent();
           
        }
    }
}
