﻿using RestSharp;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Windows.Controls;
using Guna.UI2.WinForms;
using static QRCoder.PayloadGenerator.ShadowSocksConfig;
using System.Windows;
using MessageBox = System.Windows.Forms.MessageBox;
using Application = System.Windows.Forms.Application;
using Newtonsoft.Json;

namespace Kurs_ishi
{
    public partial class Asosiy : Form
    {
        public Asosiy()
        {
            InitializeComponent();
        }

        private void Munebutton_Click(object sender, EventArgs e)
        {
            menuTimer.Start();
        }
        bool menu;
        string ism, fam, shar, yo;
        private SqlConnection con;
        private void menuTimer_Tick(object sender, EventArgs e)
        {
            if (menu)
            {
                flowLayoutPanel1.Width -= 10;
                if (flowLayoutPanel1.Width == flowLayoutPanel1.MinimumSize.Width)
                {
                    menu = false;
                    menuTimer.Stop();
                    
                }
            }
            else
            {
                flowLayoutPanel1.Width += 10;
                if (flowLayoutPanel1.Width == flowLayoutPanel1.MaximumSize.Width)
                {
                    menu = true;
                    menuTimer.Stop();
                    
                }
            }
        }



        private void Asosiy_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kurs_ishiDataSet11.Fuqarolar' table. You can move, or remove it, as needed.
            this.fuqarolarTableAdapter3.Fill(this.kurs_ishiDataSet11.Fuqarolar);
            // TODO: This line of code loads data into the 'kurs_ishiDataSet8.Fuqarolar' table. You can move, or remove it, as needed.
            this.fuqarolarTableAdapter2.Fill(this.kurs_ishiDataSet8.Fuqarolar);
            // TODO: This line of code loads data into the 'kurs_ishiDataSet7.Chaqirilganlar' table. You can move, or remove it, as needed.
            this.chaqirilganlarTableAdapter2.Fill(this.kurs_ishiDataSet7.Chaqirilganlar);

            this.fuqarolarTableAdapter1.Fill(this.kurs_ishiDataSet3.Fuqarolar);
            
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kurs"].ConnectionString);
            
            con.Open();

            qabul_panel.Dock = DockStyle.Fill;
            
            qabul2_panel.Visible = false;
            sozlamalar_panel.Visible = false;
            adminuzpanel.Visible = false;
            string Query;
            Query = "select Ism,Familiya,Sharif,Yosh,Jinsi,XizmatJoyi,XizmatTuri,HarbiyUnvoni,Kontrakt from Chaqirilganlar where Yosh>18 and Jinsi='Erkak'";
            datalbl.Text = DateTime.Now.ToString("MM/dd/yyyy");
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            DataSet dss = new DataSet();
            sda.Fill(dss);
            guna2DataGridView3.DataSource = dss.Tables[0];

            

        }
        Login admin;
        private void fillPassengers()
        {
            SqlCommand cmd = new SqlCommand("select Id from Fuqarolar", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Load(rdr);
            comboBox1.ValueMember = "Id";
            comboBox1.DataSource = dt;
        }
        private void homebtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Loginga qaytasizmi?", "Tanlang!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                admin = new Login();
                admin.Show();
                Close();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Loginga qaytasizmi?", "Tanlang!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                admin = new Login();
                admin.Show();
                Close();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            qabul_panel.Visible = false;
            qabul2_panel.Visible = false;
            sozlamalar_panel.Visible = true;
            sozlamalar_panel.Dock = DockStyle.Fill;
        }
        Help help;
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (help == null || help.IsDisposed)
            {
                help = new Help();
                help.Show();
            }
            else
            {
                help.Focus();
            }
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (infor == null || infor.IsDisposed)
            {
                infor = new Informatsiya();
                infor.Show();
            }
            else
            {
                infor.Focus();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            menuTimer.Start();
        }
        string s, c;

        private void yoshtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; 
            }
        }

        private void telefontxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '+')
            {
                e.Handled = true;
            }
        }
        
        private void editbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (ismitxt.Text == string.Empty || familiyatxt.Text == string.Empty || yoshtxt.Text == string.Empty || birthtxt.Text == string.Empty || telefontxt.Text == string.Empty || emailtxt.Text == string.Empty || millattxt.Text == string.Empty || manziltxt.Text == string.Empty || shariftxt1.Text == string.Empty)
                {
                    MessageBox.Show("Iltimos ma'lumotlarni to'liq va to'g'ri kiriting!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand($"update Fuqarolar set Ism=@Ism,Familiya=@Familiya,Sharifi=@Sharifi,Yoshi=@Yoshi,Birthday=@Birthday,Kasbi=@Kasbi,Telefon=@Telefon,Email=@Email,Jinsi=@Jinsi,Millati=@Millati,Manzili=@Manzili,Joindate=@Joindate where Id={guna2DataGridView1.SelectedRows[0].Cells[0].Value}", con);
                    if (radioButton2.Checked)
                    {
                        s = radioButton2.Text;
                    }
                    else if (radioButton2.Checked)
                    {
                        s = radioButton1.Text;
                    }
                    if (millattxt.Text == "O'zbek")
                        c = millattxt.Text;
                    if (millattxt.Text == "Qirg'iz")
                        c = millattxt.Text;
                    if (millattxt.Text == "Tojik")
                        c = millattxt.Text;
                    if (millattxt.Text == "Qozoq")
                        c = millattxt.Text;
                    if (millattxt.Text == "Turkman")
                        c = millattxt.Text;
                    if (millattxt.Text == "Rus")
                        c = millattxt.Text;
                    if (millattxt.Text == "Turk")
                        c = millattxt.Text;

                    DateTime dtk = DateTime.Parse(birthtxt.Text);
                    datalbl.Text = DateTime.Now.ToString("MM/dd/yyyy");
                    cmd.Parameters.AddWithValue("Ism", ismitxt.Text);
                    cmd.Parameters.AddWithValue("Familiya", familiyatxt.Text);
                    cmd.Parameters.AddWithValue("Sharifi", shariftxt1.Text);
                    cmd.Parameters.AddWithValue("Yoshi", yoshtxt.Text);
                    cmd.Parameters.AddWithValue("Birthday", $"{dtk.Month}/{dtk.Day}/{dtk.Year}");
                    cmd.Parameters.AddWithValue("Kasbi", kasbtxt.Text);
                    cmd.Parameters.AddWithValue("Telefon", telefontxt.Text);
                    cmd.Parameters.AddWithValue("Email", emailtxt.Text);
                    cmd.Parameters.AddWithValue("Jinsi", s);
                    cmd.Parameters.AddWithValue("Millati", c);
                    cmd.Parameters.AddWithValue("Manzili", manziltxt.Text);
                    cmd.Parameters.AddWithValue("Joindate",datalbl.Text);
                    cmd.ExecuteNonQuery().ToString();
                    MessageBox.Show("Tahrirlandi!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ismitxt.Clear(); familiyatxt.Clear(); yoshtxt.Clear(); radioButton1.Checked = false; radioButton2.Checked = false;
                    kasbtxt.Clear(); telefontxt.Clear(); emailtxt.Clear(); manziltxt.Clear(); shariftxt1.Clear(); birthtxt.Clear();
                    millattxt.Text = string.Empty; pictureBox9.Image = null;
                }
        }
            catch
            {
                MessageBox.Show("Tahrirlash uchun jadvaldan tanlang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
}

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
               
                if (c == "O'zbek" || c == "Qirg'iz" || c == "Tojik" || c == "Qozoq" || c== "Turkman" || c== "Rus" || c=="Turk")
                {
                    millattxt.Text = c;
                }

               
                ismitxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                familiyatxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                shariftxt1.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                yoshtxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                DateTime dt = DateTime.Parse(guna2DataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                birthtxt.Text = dt.ToString(); kasbtxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                telefontxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                emailtxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
                jins = guna2DataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
                millattxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[10].Value.ToString();
                manziltxt.Text = guna2DataGridView1.Rows[e.RowIndex].Cells[11].Value.ToString();
                if (jins == "Erkak")
                {
                    radioButton1.Checked = true;
                }
                else if (jins == "Ayol")
                {
                    radioButton2.Checked = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Bildirishnoma", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand($"delete from Fuqarolar where Id={guna2DataGridView1.SelectedRows[0].Cells[0].Value}", con);
                cmd.ExecuteNonQuery().ToString();
                MessageBox.Show("Muvafaqiyatli o'chirildi!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                refreshbtn.Enabled = true;
            }
            catch
            {
                MessageBox.Show("O'chirish uchun jadvaldan tanlang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tozabtn_Click(object sender, EventArgs e)
        {
            ismitxt.Clear(); familiyatxt.Clear(); yoshtxt.Clear(); radioButton1.Checked = false; radioButton2.Checked = false;
            kasbtxt.Clear(); telefontxt.Clear();  emailtxt.Clear(); manziltxt.Clear(); shariftxt1.Clear(); birthtxt.Clear();
            millattxt.Text = string.Empty; pictureBox9.Image=null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dasturdan chiqasizmi?", "Tanlang!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dasturdan chiqasizmi?", "Tanlang!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void refreshbtn_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Fuqarolar", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }

        private void qidirbtn_Click(object sender, EventArgs e)
        {
            
        }
        private void qidirtxt_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Fuqarolar", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Ism LIKE '%{0}%'", qidirtxt.Text);
                guna2DataGridView1.DataSource = dv.ToTable();
            }
            catch
            {

            }

        }

        private void qidirbtn_MouseEnter(object sender, EventArgs e)
        {
            
        }
        public string s1;
        private void printbtn_Click(object sender, EventArgs e)
        {
            if (pictureBox9.Image == null )
            {
                MessageBox.Show("Rasm yuklang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
            }
            else if(ismitxt.Text == string.Empty || familiyatxt.Text==string.Empty || kasbtxt.Text==string.Empty || telefontxt.Text==string.Empty||emailtxt.Text==string.Empty)
            {
                MessageBox.Show("Chop etish uchun jadvaldan tanlang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (radioButton1.Checked)
                {
                    s1 = radioButton1.Text;
                }
                else if (radioButton2.Checked)
                {
                    s1 = radioButton2.Text;
                }
                Chop_etish chop = new Chop_etish();
                chop.Ismi = ismitxt.Text;
                chop.Familiya = familiyatxt.Text;
                chop.Kasbi = kasbtxt.Text;
                chop.Telefon = telefontxt.Text;
                chop.Yoshi = yoshtxt.Text;
                chop.Email = emailtxt.Text;
                chop.Jinsi = s;
                chop.Millati = millattxt.Text;
                chop.Manzili = manziltxt.Text;
                chop.Img = pictureBox9.Image;
                chop.ShowDialog();
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            
        }

        private void settingsbtn_Click(object sender, EventArgs e)
        {
            qabul_panel.Visible = false;
            qabul2_panel.Visible = false;
            sozlamalar_panel.Visible = true;
            sozlamalar_panel.Dock = DockStyle.Fill;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            fillPassengers();
            fetchPassenger();


            qabul2_panel.Visible = true;
            qabul_panel.Visible=false;
            sozlamalar_panel.Visible = false;
            qabul2_panel.Dock = DockStyle.Fill;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            qabul2_panel.Visible = false;
            qabul_panel.Visible = true;
            sozlamalar_panel.Visible = false;
            qabul_panel.Dock = DockStyle.Fill;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            qabul2_panel.Visible = false;
            qabul_panel.Visible = true;
            sozlamalar_panel.Visible = false;
            qabul_panel.Dock = DockStyle.Fill;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            fillPassengers();
            fetchPassenger();


            qabul2_panel.Visible = true;
            qabul_panel.Visible = false;
            sozlamalar_panel.Visible = false;
            qabul2_panel.Dock = DockStyle.Fill;
        }

        private void kunbtn_Click(object sender, EventArgs e)
        {
            qabul_panel.BackColor = Color.White;
            qabul_panel.ForeColor = Color.Black;
            qabul2_panel.BackColor = Color.White;
            qabul2_panel.ForeColor = Color.Black;
            sozlamalar_panel.BackColor = Color.White;
            sozlamalar_panel.ForeColor = Color.Black;
            qabul_panel.BackColor = Color.White;
            qabul_panel.ForeColor = Color.Black;
            flowLayoutPanel1.BackColor = Color.White;
            flowLayoutPanel1.ForeColor = Color.Black;

        }

        private void tunbtn_Click(object sender, EventArgs e)
        {
            qabul_panel.BackColor = Color.Gray;
            qabul_panel.ForeColor = Color.White;
            qabul2_panel.BackColor = Color.Gray;
            qabul2_panel.ForeColor = Color.White;
            sozlamalar_panel.BackColor = Color.Gray;
            sozlamalar_panel.ForeColor = Color.White;
            flowLayoutPanel1.BackColor= Color.Black;
            flowLayoutPanel1.ForeColor= Color.White;

        }
        int k = 0;
        private void guna2Button1_Click(object sender, EventArgs e)
        { 
            if(k%2==0) adminuzpanel.Visible = true;
            else adminuzpanel.Visible = false;
            k++;
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '\0';
        }

        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

       

        private void uzgarbtn_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Yangi Login yoki parolingizni kiriting!");
            }
            else
            {
                try
                {
                    string query = "UPDATE Login SET Login=@Login Parol=@Parol WHERE Ism=@Ism";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Parol", textBox2.Text);
                        cmd.Parameters.AddWithValue("@Login", textBox3.Text);
                        cmd.Parameters.AddWithValue("@Ism", textBox1.Text);
                        cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Login va Parollingiz o'zgartirildi!");
                    adminuzpanel.Visible = false;
                    textBox1.Clear();
                    textBox2.Clear();
                }
                catch
                {
                    MessageBox.Show("Ismni to'g'ri kiriting!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void rasmbtn_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "JPG files(*.jpg) |*.jpg| PNG files(*.png)|*.png";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    pictureBox9.Image = System.Drawing.Image.FromFile(openFileDialog1.FileName);
                }
            }
            catch
            {
                MessageBox.Show("Qaytadan o'rinib ko'ring!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void qabul2_panel_Paint(object sender, PaintEventArgs e)
        {

        }
       
        private void qushbtn_Click(object sender, EventArgs e)
        {
            string[] viloyatlar = { "Andijon", "Toshkent", "Farg'ona", "Namangan", "Navoiy", "Sirdaryo", "Buxoro", "Samarqand", "Xorazm", "Qashqadaryo", "Surxandaryo", "Jizzax" };
            Random random = new Random();

            int randomIndex = random.Next(viloyatlar.Length);

            string tanlanganViloyat = viloyatlar[randomIndex];

            try
            {
                if (!string.IsNullOrEmpty(ism2txt.Text) && !string.IsNullOrEmpty(familiya2txt.Text) && !string.IsNullOrEmpty(yoshtxt2.Text) && !string.IsNullOrEmpty(tashxistxt.Text) && !string.IsNullOrEmpty(unvon.Text) && (radioButton3.Checked || radioButton4.Checked))
                {
                    SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Fuqarolar WHERE Ism = @Ism AND Familiya = @Familiya and Sharifi=@Sharifi", con);
                    checkCmd.Parameters.AddWithValue("@Ism", ism2txt.Text);
                    checkCmd.Parameters.AddWithValue("@Familiya", familiya2txt.Text);
                    checkCmd.Parameters.AddWithValue("@Sharifi", shariftxt.Text);

                    int existingCount = (int)checkCmd.ExecuteScalar();
                    if (existingCount > 0)
                    {
                       
                        // Jadvalga ma'lumotlarni qo'shish
                        SqlCommand cmd = new SqlCommand("INSERT INTO Chaqirilganlar (Ism, Familiya, Sharif, Jinsi, Yosh, Boyi, Vazni, Tashxis, XizmatTuri, Kontrakt, XizmatJoyi, HarbiyUnvoni) VALUES (@Ism, @Familiya, @Sharif, @Jinsi, @Yosh, @Boyi, @Vazni, @Tashxis, @XizmatTuri, @Kontrakt, @XizmatJoyi, @HarbiyUnvoni)", con);
                        string s = radioButton3.Checked ? radioButton3.Text : radioButton4.Text;

                        cmd.Parameters.AddWithValue("@Ism", ism2txt.Text);
                        cmd.Parameters.AddWithValue("@Familiya", familiya2txt.Text);
                        cmd.Parameters.AddWithValue("@Sharif", shariftxt.Text);
                        cmd.Parameters.AddWithValue("@Jinsi", s);
                        cmd.Parameters.AddWithValue("@Yosh", yoshtxt2.Text);
                        cmd.Parameters.AddWithValue("@Boyi", boyitxt.Text);
                        cmd.Parameters.AddWithValue("@Vazni", vaznitxt2.Text);
                        cmd.Parameters.AddWithValue("@Tashxis", tashxistxt.Text);
                        cmd.Parameters.AddWithValue("@XizmatTuri", xizmat.Text);
                        cmd.Parameters.AddWithValue("@Kontrakt", kontrakt.Text);
                        cmd.Parameters.AddWithValue("@XizmatJoyi", tanlanganViloyat);
                        cmd.Parameters.AddWithValue("@HarbiyUnvoni", unvon.Text);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Muvafaqiyatli qo'shildi", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Text o'lchamlarni tozalash
                            ismitxt.Clear(); familiyatxt.Clear(); yoshtxt.Clear(); radioButton1.Checked = false; radioButton2.Checked = false;
                            kasbtxt.Clear(); telefontxt.Clear(); emailtxt.Clear(); manziltxt.Clear(); birthtxt.Clear();
                            millattxt.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show("Ma'lumot qo'shilmadi!", "Xatolik", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Bu ma'lumot avval Fuqarolar ro'yxatiga kiritilmagan!", "Ogohlantirish", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Ilrimos ma'lumotlarni to'liq kiriting!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch
            {
                MessageBox.Show("Ma'lumotlarni to'g'ri kiriting!");
            }
        }

        private void refbtn_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Chaqirilganlar", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView2.DataSource = ds.Tables[0];

            string Query;
            Query = "select Ism,Familiya,Sharif,Yosh,Jinsi,XizmatJoyi,XizmatTuri,HarbiyUnvoni,Kontrakt from Chaqirilganlar where Yosh>17 and Yosh<28 and Jinsi='Erkak'";

            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            DataSet dss = new DataSet();
            sda.Fill(dss);
            guna2DataGridView3.DataSource = dss.Tables[0];
        }

        private void unvon_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(unvon, "Boshqa unvon bo'lsa o'gartirsangiz bo'ladi!");
        }

        private void tahrirbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string[] viloyatlar = { "Andijon", "Toshkent", "Farg'ona", "Namangan", "Navoiy", "Sirdaryo", "Buxoro", "Samarqand", "Xorazm", "Qashqadaryo", "Surxandaryo", "Jizzax" };
                Random random = new Random();
                int randomIndex = random.Next(viloyatlar.Length);
                string tanlanganViloyat = viloyatlar[randomIndex];

                string Query;
                Query = $"update Chaqirilganlar set Ism=@Ism,Familiya=@Familiya,Sharif=@Sharif,Jinsi=@Jinsi,Yosh=@Yosh,Boyi=@Boyi,Vazni=@Vazni,Tashxis=@Tashxis,@XizmatTuri=@XizmatTuri,Kontrakt=@Kontrakt,HarbiyUnvoni=@HarbiyUnvoni where Id={guna2DataGridView2.SelectedRows[0].Cells[0].Value}";
                SqlCommand cmd = new SqlCommand(Query, con);
                if (radioButton3.Checked)
                {
                    s = radioButton3.Text;
                }
                else if (radioButton4.Checked)
                {
                    s = radioButton4.Text;
                }
                else
                {
                    s = "Erkak";
                }

                cmd.Parameters.AddWithValue("Ism", ism2txt.Text);
                cmd.Parameters.AddWithValue("Familiya", familiya2txt.Text);
                cmd.Parameters.AddWithValue("Sharif", shariftxt.Text);
                cmd.Parameters.AddWithValue("Jinsi", s);
                cmd.Parameters.AddWithValue("Yosh", yoshtxt2.Text);
                cmd.Parameters.AddWithValue("Boyi", boyitxt.Text);
                cmd.Parameters.AddWithValue("Vazni", vaznitxt2.Text);
                cmd.Parameters.AddWithValue("Tashxis", tashxistxt.Text);
                cmd.Parameters.AddWithValue("XizmatTuri", xizmat.Text);
                cmd.Parameters.AddWithValue("Kontrakt", kontrakt.Text);
                cmd.Parameters.AddWithValue("XizmatJoyi", tanlanganViloyat);
                cmd.Parameters.AddWithValue("HarbiyUnvoni", unvon.Text);
                cmd.ExecuteNonQuery().ToString();
                ism2txt.Clear(); familiya2txt.Clear(); shariftxt.Clear();
                yoshtxt2.Clear(); tashxistxt.Text = string.Empty; kontrakt.Text = string.Empty; vaznitxt2.Clear();
                boyitxt.Clear(); xizmat.Text = string.Empty; radioButton3.Checked= false; radioButton4.Checked= false;
            }
            catch
            {
                MessageBox.Show("Ma'lumotlarni to'g'ri kiriting!");
            }

        }

        private void delbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand($"DELETE FROM Chaqirilganlar WHERE Id = @Id", con);
                cmd.Parameters.AddWithValue("@Id", guna2DataGridView2.SelectedRows[0].Cells[0].Value);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Muvafaqiyatli o'chirildi!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("O'chirishda xatolik yuz berdi!", "Xatolik", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }   

            }
            catch
            {
                MessageBox.Show("O'chirish uchun jadvaldan tanlang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void printbtn2_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Image == null)
            {
                MessageBox.Show("Rasm yuklang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (ism2txt.Text == string.Empty || familiya2txt.Text == string.Empty || shariftxt.Text == string.Empty || tashxistxt.Text == string.Empty || xizmat.Text == string.Empty)
            {
                MessageBox.Show("Chop etish uchun jadvaldan tanlang!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Chop_etish_2 chop= new Chop_etish_2();


                    chop.Ism = ism2txt.Text;
                    chop.Familiya = familiya2txt.Text;
                    chop.Sharif = shariftxt.Text;
                    chop.Tashxis = tashxistxt.Text;
                    chop.Yoshi = yoshtxt2.Text;
                    chop.Yuborilganjoy = guna2DataGridView3.SelectedRows[0].Cells[5].Value.ToString();
                    chop.Unvoni = unvon.Text;
                    chop.Jinsi = guna2DataGridView3.SelectedRows[0].Cells[4].Value.ToString();
                    chop.Manzil = manziltxt.Text;
                    chop.Img = pictureBox2.Image;

                    chop.Show();

            }
        }

        private void tozabtn2_Click(object sender, EventArgs e)
        {
            ism2txt.Clear(); familiya2txt.Clear(); shariftxt.Clear();
            yoshtxt2.Clear(); tashxistxt.Text=string.Empty; kontrakt.Text = string.Empty; vaznitxt2.Clear();
            boyitxt.Clear(); xizmat.Text=string.Empty; pictureBox2.Image = null; radioButton3.Checked = false; radioButton4.Checked = false;
        }

        private void kontrakt_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        string jins;
        private void guna2DataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            ism2txt.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[0].Value.ToString();
            familiya2txt.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[1].Value.ToString();
            shariftxt.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[2].Value.ToString();
            yoshtxt2.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[3].Value.ToString();
            tashxistxt.Text = guna2DataGridView2.Rows[e.RowIndex].Cells[7].Value.ToString();
            jins = guna2DataGridView3.Rows[e.RowIndex].Cells[4].Value.ToString();
            xizmat.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[6].Value.ToString();
            unvon.Text = guna2DataGridView3.Rows[e.RowIndex].Cells[7].Value.ToString();
            if (jins == "Erkak")
            {
                radioButton4.Checked = true;
            }
            else if (jins == "Ayol")
            {
                radioButton3.Checked = true;
            }

        }

        private void qabul_panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Chaqirilganlar", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DataView dv = dt.DefaultView;
                dv.RowFilter = string.Format("Ism LIKE '%{0}%'", guna2TextBox1.Text);
                guna2DataGridView2.DataSource = dv.ToTable();
                guna2DataGridView3.DataSource = dv.ToTable();
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "JPG files(*.jpg) |*.jpg| PNG files(*.png)|*.png";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    pictureBox2.Image = System.Drawing.Image.FromFile(openFileDialog1.FileName);
                }
            }
            catch
            {
                MessageBox.Show("Qaytadan o'rinib ko'ring!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void helpbtn_Click(object sender, EventArgs e)
        {
            if (help == null || help.IsDisposed)
            {
                help = new Help();
                help.Show();
               
            }
            else
            {
                help.Focus();
            }
        }
        Informatsiya infor;
        private void fetchPassenger()
        {
            SqlCommand cmd1 = new SqlCommand($"select * from Fuqarolar where Id={comboBox1.SelectedValue}", con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                ism = dr["Ism"].ToString();
                fam = dr["Familiya"].ToString();
                shar = dr["Sharifi"].ToString();
                yo = dr["Yoshi"].ToString();
                ism2txt.Text = ism;
                familiya2txt.Text = fam;
                shariftxt.Text = shar;
                yoshtxt2.Text = yo;
            }
        }
        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchPassenger();
        }

        private void aboutbtn_Click(object sender, EventArgs e)
        {
            if (infor == null || infor.IsDisposed)
            {
                infor = new Informatsiya();
                infor.Show();

            }
            else
            {
                infor.Focus();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (k % 2 == 0)
            {
                button6.Text = "▢";
                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                button6.Text = "-";
                this.FormBorderStyle = FormBorderStyle.None;
                this.WindowState = FormWindowState.Maximized;
            }

            k++;
        }
        private async void button7_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != string.Empty)
            {
                var options = new RestClientOptions("https://n8wjk2.api.infobip.com")
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);
                var request = new RestRequest("/sms/2/text/advanced", RestSharp.Method.Post);
                request.AddHeader("Authorization", "App 02d9b895003c6acd871491b048ca4f19-c89957a8-2c14-4c8e-b96d-8ec8cc3df5db");
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Accept", "application/json");
                string stext = richTextBox1.Text;

                // JSON formatini to'g'ri shakllantirish
                var body = new
                {
                    messages = new[]
                    {
                        new
                        {
                destinations = new[]
                {
                    new { to = "998919647735" }
                },
                from = "Murojaat",
                text = stext
            }
        }
                };

                // JSON obyektini serialize qilish
                string jsonBody = JsonConvert.SerializeObject(body);
                request.AddStringBody(jsonBody, RestSharp.DataFormat.Json);

                RestResponse response = await client.ExecuteAsync(request);
                MessageBox.Show(response.Content);
                richTextBox1.Clear();
            }
            else
            {
                MessageBox.Show("Xabar yuborish uchun matn kiriting!","Xata",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void savebtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (ismitxt.Text == string.Empty || familiyatxt.Text == string.Empty || yoshtxt.Text == string.Empty || birthtxt.Text == string.Empty || telefontxt.Text == string.Empty || emailtxt.Text == string.Empty || shariftxt1.Text == string.Empty)
                {
                    MessageBox.Show("Ilrimos ma'lumotlarni to'liq kiriting!", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                        if (radioButton2.Checked)
                        {
                            s = radioButton2.Text;
                        }
                        else if (radioButton1.Checked)
                        {
                            s = radioButton1.Text;
                        }
                        else
                        {
                            s = "Erkak";
                        }

                        if (millattxt.Text == "O'zbek" || millattxt.Text == "Qirg'iz" || millattxt.Text == "Tojik" || millattxt.Text == "Qozoq" || millattxt.Text == "Turkman" || millattxt.Text == "Rus" || millattxt.Text == "Turk")
                        {
                            c = millattxt.Text;
                        }
                        else
                        {
                            c = "O'zbek"; 
                        }


                    SqlCommand  cmd = new SqlCommand($"if not EXISTS (select 1 from Fuqarolar where Ism = @Ism and Sharifi=@Sharifi and Familiya = @Familiya and Jinsi = @Jinsi and Email = @Email) Begin INSERT INTO Fuqarolar (Ism,Familiya,Sharifi,Yoshi,Birthday,Kasbi,Telefon,Email,Jinsi,Millati,Manzili,Joindate) VALUES (@Ism,@Familiya,@Sharifi,@Yoshi,@Birthday,@Kasbi,@Telefon,@Email,@Jinsi,@Millati,@Manzili,@Joindate) End", con);

                   
                        DateTime dtk = DateTime.Parse(birthtxt.Text);
                    datalbl.Text = DateTime.Now.ToString("MM/dd/yyyy");
                     cmd.Parameters.AddWithValue("Ism", ismitxt.Text);
                     cmd.Parameters.AddWithValue("Familiya", familiyatxt.Text);
                     cmd.Parameters.AddWithValue("Sharifi", shariftxt1.Text);
                     cmd.Parameters.AddWithValue("Yoshi", yoshtxt.Text);
                     cmd.Parameters.AddWithValue("Birthday", $"{dtk.Month}/{dtk.Day}/{dtk.Year}");
                     cmd.Parameters.AddWithValue("Kasbi", kasbtxt.Text);
                     cmd.Parameters.AddWithValue("Telefon", telefontxt.Text);
                     cmd.Parameters.AddWithValue("Email", emailtxt.Text);
                     cmd.Parameters.AddWithValue("Jinsi", s);
                     cmd.Parameters.AddWithValue("Millati", c);
                     cmd.Parameters.AddWithValue("Manzili", manziltxt.Text);
                     cmd.Parameters.AddWithValue("Joindate", datalbl.Text);
                    
                    cmd.ExecuteNonQuery().ToString();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected >= 0)
                    {
                        MessageBox.Show("Muvafaqiyatli qo'shildi", "Ma'lumot", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ismitxt.Clear(); familiyatxt.Clear(); yoshtxt.Clear(); radioButton1.Checked = false; radioButton2.Checked = false;
                        kasbtxt.Clear(); telefontxt.Clear(); emailtxt.Clear(); manziltxt.Clear(); shariftxt1.Clear(); birthtxt.Clear();
                        millattxt.Text = string.Empty; pictureBox9.Image = null;
                    }
                    else
                    {
                        MessageBox.Show("Bunday ma'lumot avval kiritilgan!", "Xatolik", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                       
                }
            }
            catch
            {
                MessageBox.Show("Ma'lumotlarni to'g'ri kiriting!");
            }
        }
    }
}
 