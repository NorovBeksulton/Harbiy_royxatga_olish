﻿namespace Kurs_ishi
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.loginBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet = new Kurs_ishi.Kurs_ishiDataSet();
            this.loginTableAdapter = new Kurs_ishi.Kurs_ishiDataSetTableAdapters.LoginTableAdapter();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.kirbtn = new Guna.UI2.WinForms.Guna2Button();
            this.chiqbtn = new Guna.UI2.WinForms.Guna2Button();
            this.kunbtn = new Guna.UI2.WinForms.Guna2Button();
            this.tunbtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.admintekpanel = new System.Windows.Forms.Panel();
            this.tasdiqbtn = new Guna.UI2.WinForms.Guna2Button();
            this.eyebtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.adminlogin = new System.Windows.Forms.TextBox();
            this.adminparol = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.adminuzpanel = new System.Windows.Forms.Panel();
            this.refreshbtn = new Guna.UI2.WinForms.Guna2Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ismDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loginDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parolDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.kirishbtn = new Guna.UI2.WinForms.Guna2Button();
            this.chiqishbtn = new Guna.UI2.WinForms.Guna2Button();
            this.uchirishbtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.admintekpanel.SuspendLayout();
            this.adminuzpanel.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            this.guna2TabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1256, 672);
            this.guna2Panel1.TabIndex = 0;
            // 
            // loginBindingSource
            // 
            this.loginBindingSource.DataMember = "Login";
            this.loginBindingSource.DataSource = this.kurs_ishiDataSet;
            // 
            // kurs_ishiDataSet
            // 
            this.kurs_ishiDataSet.DataSetName = "Kurs_ishiDataSet";
            this.kurs_ishiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginTableAdapter
            // 
            this.loginTableAdapter.ClearBeforeFill = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.kirbtn);
            this.tabPage4.Controls.Add(this.chiqbtn);
            this.tabPage4.Controls.Add(this.kunbtn);
            this.tabPage4.Controls.Add(this.tunbtn);
            this.tabPage4.Controls.Add(this.guna2Button1);
            this.tabPage4.Controls.Add(this.pictureBox2);
            this.tabPage4.Controls.Add(this.admintekpanel);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.adminuzpanel);
            this.tabPage4.Location = new System.Drawing.Point(184, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1068, 664);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sozlamalar";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // kirbtn
            // 
            this.kirbtn.BorderRadius = 50;
            this.kirbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.kirbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.kirbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.kirbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.kirbtn.FillColor = System.Drawing.Color.Transparent;
            this.kirbtn.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Bold);
            this.kirbtn.ForeColor = System.Drawing.Color.White;
            this.kirbtn.Image = global::Kurs_ishi.Properties.Resources.right_arrow__2_;
            this.kirbtn.Location = new System.Drawing.Point(926, 8);
            this.kirbtn.Name = "kirbtn";
            this.kirbtn.Size = new System.Drawing.Size(46, 49);
            this.kirbtn.TabIndex = 33;
            this.kirbtn.Click += new System.EventHandler(this.kirbtn_Click);
            this.kirbtn.MouseEnter += new System.EventHandler(this.kirbtn_MouseEnter);
            // 
            // chiqbtn
            // 
            this.chiqbtn.BorderRadius = 15;
            this.chiqbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.chiqbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.chiqbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.chiqbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.chiqbtn.FillColor = System.Drawing.Color.Transparent;
            this.chiqbtn.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chiqbtn.ForeColor = System.Drawing.Color.White;
            this.chiqbtn.Image = global::Kurs_ishi.Properties.Resources.delete1;
            this.chiqbtn.Location = new System.Drawing.Point(849, 9);
            this.chiqbtn.Name = "chiqbtn";
            this.chiqbtn.Size = new System.Drawing.Size(46, 48);
            this.chiqbtn.TabIndex = 32;
            this.chiqbtn.Click += new System.EventHandler(this.chiqbtn_Click);
            this.chiqbtn.MouseEnter += new System.EventHandler(this.chiqbtn_MouseEnter);
            // 
            // kunbtn
            // 
            this.kunbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.kunbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.kunbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.kunbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.kunbtn.FillColor = System.Drawing.Color.Transparent;
            this.kunbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.kunbtn.ForeColor = System.Drawing.Color.White;
            this.kunbtn.Image = global::Kurs_ishi.Properties.Resources.sun;
            this.kunbtn.ImageSize = new System.Drawing.Size(30, 30);
            this.kunbtn.Location = new System.Drawing.Point(27, 559);
            this.kunbtn.Name = "kunbtn";
            this.kunbtn.Size = new System.Drawing.Size(57, 52);
            this.kunbtn.TabIndex = 31;
            this.kunbtn.Click += new System.EventHandler(this.kunbtn_Click);
            // 
            // tunbtn
            // 
            this.tunbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tunbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tunbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tunbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tunbtn.FillColor = System.Drawing.Color.Transparent;
            this.tunbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.tunbtn.ForeColor = System.Drawing.Color.White;
            this.tunbtn.Image = global::Kurs_ishi.Properties.Resources.moon;
            this.tunbtn.ImageSize = new System.Drawing.Size(30, 30);
            this.tunbtn.Location = new System.Drawing.Point(117, 559);
            this.tunbtn.Name = "tunbtn";
            this.tunbtn.Size = new System.Drawing.Size(56, 52);
            this.tunbtn.TabIndex = 31;
            this.tunbtn.Click += new System.EventHandler(this.tunbtn_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 15;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.ForestGreen;
            this.guna2Button1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(372, 122);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(162, 44);
            this.guna2Button1.TabIndex = 30;
            this.guna2Button1.Text = "O\'gartirish";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(129, 113);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // admintekpanel
            // 
            this.admintekpanel.Controls.Add(this.tasdiqbtn);
            this.admintekpanel.Controls.Add(this.eyebtn);
            this.admintekpanel.Controls.Add(this.label5);
            this.admintekpanel.Controls.Add(this.label6);
            this.admintekpanel.Controls.Add(this.adminlogin);
            this.admintekpanel.Controls.Add(this.adminparol);
            this.admintekpanel.Location = new System.Drawing.Point(120, 171);
            this.admintekpanel.Name = "admintekpanel";
            this.admintekpanel.Size = new System.Drawing.Size(599, 256);
            this.admintekpanel.TabIndex = 28;
            // 
            // tasdiqbtn
            // 
            this.tasdiqbtn.BorderRadius = 15;
            this.tasdiqbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tasdiqbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tasdiqbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tasdiqbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tasdiqbtn.FillColor = System.Drawing.Color.RoyalBlue;
            this.tasdiqbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tasdiqbtn.ForeColor = System.Drawing.Color.White;
            this.tasdiqbtn.Location = new System.Drawing.Point(232, 192);
            this.tasdiqbtn.Name = "tasdiqbtn";
            this.tasdiqbtn.Size = new System.Drawing.Size(165, 48);
            this.tasdiqbtn.TabIndex = 35;
            this.tasdiqbtn.Text = "Tekshirish";
            this.tasdiqbtn.Click += new System.EventHandler(this.tasdiqbtn_Click);
            // 
            // eyebtn
            // 
            this.eyebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eyebtn.Image = ((System.Drawing.Image)(resources.GetObject("eyebtn.Image")));
            this.eyebtn.Location = new System.Drawing.Point(514, 121);
            this.eyebtn.Name = "eyebtn";
            this.eyebtn.Size = new System.Drawing.Size(51, 39);
            this.eyebtn.TabIndex = 34;
            this.eyebtn.UseVisualStyleBackColor = true;
            this.eyebtn.Click += new System.EventHandler(this.eyebtn_Click);
            this.eyebtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseDown);
            this.eyebtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 23);
            this.label5.TabIndex = 29;
            this.label5.Text = "Login:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 23);
            this.label6.TabIndex = 29;
            this.label6.Text = "Parol";
            // 
            // adminlogin
            // 
            this.adminlogin.Location = new System.Drawing.Point(207, 65);
            this.adminlogin.Name = "adminlogin";
            this.adminlogin.Size = new System.Drawing.Size(278, 30);
            this.adminlogin.TabIndex = 27;
            // 
            // adminparol
            // 
            this.adminparol.Location = new System.Drawing.Point(207, 130);
            this.adminparol.Name = "adminparol";
            this.adminparol.PasswordChar = '*';
            this.adminparol.Size = new System.Drawing.Size(278, 30);
            this.adminparol.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(-3, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(339, 32);
            this.label7.TabIndex = 26;
            this.label7.Text = "Admin parolini o\'zgartirish:";
            // 
            // adminuzpanel
            // 
            this.adminuzpanel.Controls.Add(this.refreshbtn);
            this.adminuzpanel.Controls.Add(this.button2);
            this.adminuzpanel.Controls.Add(this.label8);
            this.adminuzpanel.Controls.Add(this.label9);
            this.adminuzpanel.Controls.Add(this.textBox1);
            this.adminuzpanel.Controls.Add(this.textBox2);
            this.adminuzpanel.Location = new System.Drawing.Point(117, 171);
            this.adminuzpanel.Name = "adminuzpanel";
            this.adminuzpanel.Size = new System.Drawing.Size(599, 256);
            this.adminuzpanel.TabIndex = 28;
            // 
            // refreshbtn
            // 
            this.refreshbtn.BorderRadius = 15;
            this.refreshbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.refreshbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.refreshbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refreshbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.refreshbtn.FillColor = System.Drawing.Color.RoyalBlue;
            this.refreshbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.refreshbtn.ForeColor = System.Drawing.Color.White;
            this.refreshbtn.Location = new System.Drawing.Point(234, 192);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(165, 48);
            this.refreshbtn.TabIndex = 35;
            this.refreshbtn.Text = "O\'zgartirish";
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(514, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(51, 39);
            this.button2.TabIndex = 39;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button2_MouseDown);
            this.button2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button2_MouseUp);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 23);
            this.label8.TabIndex = 37;
            this.label8.Text = "Login:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(44, 122);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 23);
            this.label9.TabIndex = 38;
            this.label9.Text = "Parol";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(200, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(278, 30);
            this.textBox1.TabIndex = 35;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(200, 122);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(278, 30);
            this.textBox2.TabIndex = 36;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.guna2DataGridView1);
            this.tabPage1.Controls.Add(this.guna2TextBox1);
            this.tabPage1.Controls.Add(this.kirishbtn);
            this.tabPage1.Controls.Add(this.chiqishbtn);
            this.tabPage1.Controls.Add(this.uchirishbtn);
            this.tabPage1.Location = new System.Drawing.Point(184, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1068, 664);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Adminlarni ko\'rish";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // guna2DataGridView1
            // 
            this.guna2DataGridView1.AllowUserToAddRows = false;
            this.guna2DataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.AutoGenerateColumns = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 22;
            this.guna2DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.ismDataGridViewTextBoxColumn,
            this.loginDataGridViewTextBoxColumn,
            this.parolDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn});
            this.guna2DataGridView1.DataSource = this.loginBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(3, 353);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.ReadOnly = true;
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 62;
            this.guna2DataGridView1.RowTemplate.Height = 28;
            this.guna2DataGridView1.Size = new System.Drawing.Size(1062, 308);
            this.guna2DataGridView1.TabIndex = 0;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 22;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 28;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.guna2DataGridView1_CellFormatting);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ismDataGridViewTextBoxColumn
            // 
            this.ismDataGridViewTextBoxColumn.DataPropertyName = "Ism";
            this.ismDataGridViewTextBoxColumn.HeaderText = "Ism";
            this.ismDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.ismDataGridViewTextBoxColumn.Name = "ismDataGridViewTextBoxColumn";
            this.ismDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // loginDataGridViewTextBoxColumn
            // 
            this.loginDataGridViewTextBoxColumn.DataPropertyName = "Login";
            this.loginDataGridViewTextBoxColumn.HeaderText = "Login";
            this.loginDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.loginDataGridViewTextBoxColumn.Name = "loginDataGridViewTextBoxColumn";
            this.loginDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // parolDataGridViewTextBoxColumn
            // 
            this.parolDataGridViewTextBoxColumn.DataPropertyName = "Parol";
            this.parolDataGridViewTextBoxColumn.HeaderText = "Parol";
            this.parolDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.parolDataGridViewTextBoxColumn.Name = "parolDataGridViewTextBoxColumn";
            this.parolDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderColor = System.Drawing.Color.Black;
            this.guna2TextBox1.BorderRadius = 10;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(0, 176);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "Qidirish";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(253, 34);
            this.guna2TextBox1.TabIndex = 3;
            this.guna2TextBox1.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // kirishbtn
            // 
            this.kirishbtn.BorderRadius = 50;
            this.kirishbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.kirishbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.kirishbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.kirishbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.kirishbtn.FillColor = System.Drawing.Color.Transparent;
            this.kirishbtn.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kirishbtn.ForeColor = System.Drawing.Color.White;
            this.kirishbtn.Image = global::Kurs_ishi.Properties.Resources.right_arrow__2_;
            this.kirishbtn.Location = new System.Drawing.Point(925, 6);
            this.kirishbtn.Name = "kirishbtn";
            this.kirishbtn.Size = new System.Drawing.Size(57, 53);
            this.kirishbtn.TabIndex = 1;
            this.kirishbtn.Click += new System.EventHandler(this.kirishbtn_Click);
            this.kirishbtn.MouseEnter += new System.EventHandler(this.guna2Button2_MouseEnter);
            // 
            // chiqishbtn
            // 
            this.chiqishbtn.BorderRadius = 15;
            this.chiqishbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.chiqishbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.chiqishbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.chiqishbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.chiqishbtn.FillColor = System.Drawing.Color.Transparent;
            this.chiqishbtn.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chiqishbtn.ForeColor = System.Drawing.Color.White;
            this.chiqishbtn.Image = global::Kurs_ishi.Properties.Resources.delete1;
            this.chiqishbtn.Location = new System.Drawing.Point(857, 6);
            this.chiqishbtn.Name = "chiqishbtn";
            this.chiqishbtn.Size = new System.Drawing.Size(50, 53);
            this.chiqishbtn.TabIndex = 1;
            this.chiqishbtn.Click += new System.EventHandler(this.chiqishbtn_Click);
            this.chiqishbtn.MouseEnter += new System.EventHandler(this.chiqishbtn_MouseEnter);
            // 
            // uchirishbtn
            // 
            this.uchirishbtn.BorderRadius = 15;
            this.uchirishbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.uchirishbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.uchirishbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.uchirishbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.uchirishbtn.FillColor = System.Drawing.Color.Red;
            this.uchirishbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.uchirishbtn.ForeColor = System.Drawing.Color.White;
            this.uchirishbtn.Location = new System.Drawing.Point(294, 169);
            this.uchirishbtn.Name = "uchirishbtn";
            this.uchirishbtn.Size = new System.Drawing.Size(175, 41);
            this.uchirishbtn.TabIndex = 1;
            this.uchirishbtn.Text = "O\'chirish";
            this.uchirishbtn.Click += new System.EventHandler(this.uchirishbtn_Click);
            // 
            // guna2TabControl1
            // 
            this.guna2TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.guna2TabControl1.Controls.Add(this.tabPage1);
            this.guna2TabControl1.Controls.Add(this.tabPage4);
            this.guna2TabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2TabControl1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2TabControl1.ItemSize = new System.Drawing.Size(180, 40);
            this.guna2TabControl1.Location = new System.Drawing.Point(0, 0);
            this.guna2TabControl1.Name = "guna2TabControl1";
            this.guna2TabControl1.SelectedIndex = 0;
            this.guna2TabControl1.Size = new System.Drawing.Size(1256, 672);
            this.guna2TabControl1.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonHoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonHoverState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(52)))), ((int)(((byte)(70)))));
            this.guna2TabControl1.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonIdleState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(160)))), ((int)(((byte)(167)))));
            this.guna2TabControl1.TabButtonIdleState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty;
            this.guna2TabControl1.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(37)))), ((int)(((byte)(49)))));
            this.guna2TabControl1.TabButtonSelectedState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.guna2TabControl1.TabButtonSelectedState.ForeColor = System.Drawing.Color.White;
            this.guna2TabControl1.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(132)))), ((int)(((byte)(255)))));
            this.guna2TabControl1.TabButtonSize = new System.Drawing.Size(180, 40);
            this.guna2TabControl1.TabIndex = 1;
            this.guna2TabControl1.TabMenuBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(42)))), ((int)(((byte)(57)))));
            this.guna2TabControl1.Tag = "";
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 672);
            this.Controls.Add(this.guna2TabControl1);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.admintekpanel.ResumeLayout(false);
            this.admintekpanel.PerformLayout();
            this.adminuzpanel.ResumeLayout(false);
            this.adminuzpanel.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            this.guna2TabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Kurs_ishiDataSet kurs_ishiDataSet;
        private System.Windows.Forms.BindingSource loginBindingSource;
        private Kurs_ishiDataSetTableAdapters.LoginTableAdapter loginTableAdapter;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel admintekpanel;
        private Guna.UI2.WinForms.Guna2Button tasdiqbtn;
        private System.Windows.Forms.Button eyebtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox adminlogin;
        private System.Windows.Forms.TextBox adminparol;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel adminuzpanel;
        private Guna.UI2.WinForms.Guna2Button refreshbtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TabPage tabPage1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ismDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loginDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parolDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2Button kirishbtn;
        private Guna.UI2.WinForms.Guna2Button chiqishbtn;
        private Guna.UI2.WinForms.Guna2Button uchirishbtn;
        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private Guna.UI2.WinForms.Guna2Button kunbtn;
        private Guna.UI2.WinForms.Guna2Button tunbtn;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button chiqbtn;
        private Guna.UI2.WinForms.Guna2Button kirbtn;
    }
}