﻿namespace Kurs_ishi
{
    partial class Forgotpasword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Forgotpasword));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.parolbtn = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Paroltxt = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.eyebtn = new System.Windows.Forms.Button();
            this.yangitbn = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.orqabtn = new System.Windows.Forms.Button();
            this.guna2Panel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.SpringGreen;
            this.guna2Panel1.Controls.Add(this.orqabtn);
            this.guna2Panel1.Controls.Add(this.textBox4);
            this.guna2Panel1.Controls.Add(this.textBox3);
            this.guna2Panel1.Controls.Add(this.panel1);
            this.guna2Panel1.Controls.Add(this.panel2);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(450, 432);
            this.guna2Panel1.TabIndex = 0;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(940, 449);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(10, 30);
            this.textBox4.TabIndex = 44;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(904, 449);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(10, 30);
            this.textBox3.TabIndex = 43;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.parolbtn);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Paroltxt);
            this.panel1.Location = new System.Drawing.Point(56, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(345, 335);
            this.panel1.TabIndex = 36;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Kurs_ishi.Properties.Resources.share;
            this.pictureBox1.Location = new System.Drawing.Point(124, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 92);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // parolbtn
            // 
            this.parolbtn.BorderRadius = 15;
            this.parolbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.parolbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.parolbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.parolbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.parolbtn.FillColor = System.Drawing.Color.RoyalBlue;
            this.parolbtn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.parolbtn.ForeColor = System.Drawing.Color.White;
            this.parolbtn.Location = new System.Drawing.Point(71, 254);
            this.parolbtn.Name = "parolbtn";
            this.parolbtn.Size = new System.Drawing.Size(196, 39);
            this.parolbtn.TabIndex = 40;
            this.parolbtn.Text = "Kodni bilish";
            this.parolbtn.Click += new System.EventHandler(this.parolbtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(81, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 22);
            this.label6.TabIndex = 39;
            this.label6.Text = "Emailingizni kiriting!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(28, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 22);
            this.label2.TabIndex = 35;
            this.label2.Text = "Email";
            // 
            // Paroltxt
            // 
            this.Paroltxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Paroltxt.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Paroltxt.Location = new System.Drawing.Point(32, 192);
            this.Paroltxt.Name = "Paroltxt";
            this.Paroltxt.Size = new System.Drawing.Size(285, 30);
            this.Paroltxt.TabIndex = 33;
            this.Paroltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Paroltxt_KeyDown);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.eyebtn);
            this.panel2.Controls.Add(this.yangitbn);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Location = new System.Drawing.Point(41, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(383, 410);
            this.panel2.TabIndex = 37;
            // 
            // eyebtn
            // 
            this.eyebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eyebtn.Image = ((System.Drawing.Image)(resources.GetObject("eyebtn.Image")));
            this.eyebtn.Location = new System.Drawing.Point(319, 299);
            this.eyebtn.Name = "eyebtn";
            this.eyebtn.Size = new System.Drawing.Size(53, 39);
            this.eyebtn.TabIndex = 42;
            this.eyebtn.UseVisualStyleBackColor = true;
            this.eyebtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseDown);
            this.eyebtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.eyebtn_MouseUp);
            // 
            // yangitbn
            // 
            this.yangitbn.Animated = true;
            this.yangitbn.BorderRadius = 15;
            this.yangitbn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.yangitbn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.yangitbn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.yangitbn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.yangitbn.FillColor = System.Drawing.Color.RoyalBlue;
            this.yangitbn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.yangitbn.ForeColor = System.Drawing.Color.White;
            this.yangitbn.Location = new System.Drawing.Point(86, 356);
            this.yangitbn.Name = "yangitbn";
            this.yangitbn.Size = new System.Drawing.Size(196, 39);
            this.yangitbn.TabIndex = 40;
            this.yangitbn.Text = "Yangilash";
            this.yangitbn.Click += new System.EventHandler(this.yangitbn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Kurs_ishi.Properties.Resources._lock;
            this.pictureBox2.Location = new System.Drawing.Point(149, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 92);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(24, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 22);
            this.label3.TabIndex = 39;
            this.label3.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(79, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(234, 44);
            this.label5.TabIndex = 38;
            this.label5.Text = "Yangi parol va loginingizni \r\n    kiritsangiz ham bo\'ladi!";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(24, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 22);
            this.label4.TabIndex = 38;
            this.label4.Text = "Login";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(28, 226);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(285, 30);
            this.textBox1.TabIndex = 37;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(28, 305);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(285, 30);
            this.textBox2.TabIndex = 36;
            // 
            // orqabtn
            // 
            this.orqabtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.orqabtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orqabtn.Location = new System.Drawing.Point(0, 0);
            this.orqabtn.Name = "orqabtn";
            this.orqabtn.Size = new System.Drawing.Size(50, 41);
            this.orqabtn.TabIndex = 16;
            this.orqabtn.TabStop = false;
            this.orqabtn.Text = "↩";
            this.orqabtn.UseVisualStyleBackColor = true;
            this.orqabtn.Click += new System.EventHandler(this.orqabtn_Click);
            // 
            // Forgotpasword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 432);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Forgotpasword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Parolni qayta tiklash";
            this.Load += new System.EventHandler(this.Forgotpasword_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Paroltxt;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button yangitbn;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Button parolbtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button eyebtn;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button orqabtn;
    }
}