﻿using Guna.UI2.WinForms;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace Kurs_ishi
{
    public partial class Informatsiya : Form
    {
        public Informatsiya()
        {
            InitializeComponent();
        }
        SqlConnection con;
        private void Informatsiya_Load(object sender, EventArgs e)
        {

            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kurs"].ConnectionString);

            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Fuqarolar", con);
            SqlCommand cmd1 = new SqlCommand("Select MAX(Yosh) AS EngKattaYosh, AVG(Yosh) AS OrtachaYosh, MIN(Yosh) AS EngKichikYosh, Count(Id) as id from Chaqirilganlar", con);
            SqlDataAdapter sda = new SqlDataAdapter("Select Ism,Familiya,Sharifi,Jinsi,Yoshi from Fuqarolar", con);
            DataSet dss = new DataSet();
            sda.Fill(dss);  
            SqlDataAdapter da = new SqlDataAdapter("Select Ism,Familiya,Sharif,Jinsi,Yosh from Chaqirilganlar where Jinsi='Erkak' and Yosh>17 and Yosh<27 ", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = dss.Tables[0];
            guna2DataGridView2.DataSource = ds.Tables[0];

            try
            {
                int erkaklarSoni = 0;
                int ayollarSoni = 0;
                int jamiFuqarolarSoni = 0;

                using (SqlDataReader myreader = cmd.ExecuteReader())
                {
                    while (myreader.Read())
                    {
                        string jinsi = myreader["Jinsi"].ToString();

                        if (jinsi == "Erkak")
                            erkaklarSoni++;
                        else if (jinsi == "Ayol")
                            ayollarSoni++;
                    }
                }
                SqlDataReader reader = cmd1.ExecuteReader();
                if (reader.Read())
                {
                    // Grafik uchun ma'lumotlarni olish
                    int engKattaYosh = Convert.ToInt32(reader["EngKattaYosh"]);
                    double ortachaYosh = Convert.ToDouble(reader["OrtachaYosh"]);
                    int engKichikYosh = Convert.ToInt32(reader["EngKichikYosh"]);
                    int id = Convert.ToInt32(reader["Id"]);
                    label4.Text = id.ToString();
                    chart2.Titles.Add("Chaqirilganlar");
                    chart2.Series[0].Points.AddXY($"Eng katta yosh:\n{engKattaYosh}", engKattaYosh);
                    chart2.Series[0].Points.AddXY($"O'rtacha yosh:\n{ortachaYosh}", ortachaYosh);
                    chart2.Series[0].Points.AddXY($"Eng kichik yosh:\n{engKichikYosh}", engKichikYosh);
                }

                jamiFuqarolarSoni = erkaklarSoni + ayollarSoni;


                double erkaklarFoizi = (double)erkaklarSoni / jamiFuqarolarSoni * 100;
                double ayollarFoizi = (double)ayollarSoni / jamiFuqarolarSoni * 100;
                label2.Text = jamiFuqarolarSoni.ToString();
                chart1.Titles.Add("Fuqarolar");
                chart1.Series[0].Points.AddXY($"Erkaklar:\n{erkaklarFoizi}%", erkaklarSoni);
                chart1.Series[0].Points.AddXY($"Ayollar:\n{ayollarFoizi}%", ayollarSoni);
               

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
