﻿namespace Kurs_ishi
{
    partial class Chop_etish
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Chop_etish));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.todaylb = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.emaillb = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.yoshlb = new System.Windows.Forms.Label();
            this.tellb = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.manzillb = new System.Windows.Forms.Label();
            this.millatlb = new System.Windows.Forms.Label();
            this.jinslb = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.kasblb = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.familiyalb = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ismlb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.qrcodebox = new System.Windows.Forms.PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.qrbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrcodebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.White;
            this.guna2Panel1.Controls.Add(this.label7);
            this.guna2Panel1.Controls.Add(this.label6);
            this.guna2Panel1.Controls.Add(this.todaylb);
            this.guna2Panel1.Controls.Add(this.label5);
            this.guna2Panel1.Controls.Add(this.label13);
            this.guna2Panel1.Controls.Add(this.label3);
            this.guna2Panel1.Controls.Add(this.emaillb);
            this.guna2Panel1.Controls.Add(this.label11);
            this.guna2Panel1.Controls.Add(this.yoshlb);
            this.guna2Panel1.Controls.Add(this.tellb);
            this.guna2Panel1.Controls.Add(this.label2);
            this.guna2Panel1.Controls.Add(this.manzillb);
            this.guna2Panel1.Controls.Add(this.millatlb);
            this.guna2Panel1.Controls.Add(this.jinslb);
            this.guna2Panel1.Controls.Add(this.label12);
            this.guna2Panel1.Controls.Add(this.kasblb);
            this.guna2Panel1.Controls.Add(this.label9);
            this.guna2Panel1.Controls.Add(this.familiyalb);
            this.guna2Panel1.Controls.Add(this.label14);
            this.guna2Panel1.Controls.Add(this.label8);
            this.guna2Panel1.Controls.Add(this.ismlb);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Controls.Add(this.pictureBox1);
            this.guna2Panel1.Controls.Add(this.label4);
            this.guna2Panel1.Controls.Add(this.qrcodebox);
            this.guna2Panel1.Controls.Add(this.guna2PictureBox1);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Panel1.Location = new System.Drawing.Point(0, 39);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(945, 1011);
            this.guna2Panel1.TabIndex = 0;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(407, 949);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(190, 23);
            this.label7.TabIndex = 36;
            this.label7.Text = "__________________";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(480, 984);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 23);
            this.label6.TabIndex = 36;
            this.label6.Text = "Imzo";
            // 
            // todaylb
            // 
            this.todaylb.AutoSize = true;
            this.todaylb.Location = new System.Drawing.Point(155, 949);
            this.todaylb.Name = "todaylb";
            this.todaylb.Size = new System.Drawing.Size(20, 23);
            this.todaylb.TabIndex = 36;
            this.todaylb.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 949);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 23);
            this.label5.TabIndex = 36;
            this.label5.Text = "Bugungi sana:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(56, 547);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 32);
            this.label13.TabIndex = 36;
            this.label13.Text = "Emaili:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(56, 483);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 32);
            this.label3.TabIndex = 36;
            this.label3.Text = "Yoshi";
            // 
            // emaillb
            // 
            this.emaillb.AutoSize = true;
            this.emaillb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.emaillb.Location = new System.Drawing.Point(210, 547);
            this.emaillb.Name = "emaillb";
            this.emaillb.Size = new System.Drawing.Size(28, 32);
            this.emaillb.TabIndex = 36;
            this.emaillb.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(56, 515);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 32);
            this.label11.TabIndex = 36;
            this.label11.Text = "Telefoni:";
            // 
            // yoshlb
            // 
            this.yoshlb.AutoSize = true;
            this.yoshlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yoshlb.Location = new System.Drawing.Point(210, 483);
            this.yoshlb.Name = "yoshlb";
            this.yoshlb.Size = new System.Drawing.Size(28, 32);
            this.yoshlb.TabIndex = 36;
            this.yoshlb.Text = "*";
            // 
            // tellb
            // 
            this.tellb.AutoSize = true;
            this.tellb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tellb.Location = new System.Drawing.Point(210, 515);
            this.tellb.Name = "tellb";
            this.tellb.Size = new System.Drawing.Size(28, 32);
            this.tellb.TabIndex = 36;
            this.tellb.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(56, 451);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 32);
            this.label2.TabIndex = 36;
            this.label2.Text = "Familiyasi:";
            // 
            // manzillb
            // 
            this.manzillb.AutoSize = true;
            this.manzillb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.manzillb.Location = new System.Drawing.Point(210, 673);
            this.manzillb.Name = "manzillb";
            this.manzillb.Size = new System.Drawing.Size(28, 32);
            this.manzillb.TabIndex = 36;
            this.manzillb.Text = "*";
            // 
            // millatlb
            // 
            this.millatlb.AutoSize = true;
            this.millatlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.millatlb.Location = new System.Drawing.Point(210, 641);
            this.millatlb.Name = "millatlb";
            this.millatlb.Size = new System.Drawing.Size(28, 32);
            this.millatlb.TabIndex = 36;
            this.millatlb.Text = "*";
            // 
            // jinslb
            // 
            this.jinslb.AutoSize = true;
            this.jinslb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.jinslb.Location = new System.Drawing.Point(210, 608);
            this.jinslb.Name = "jinslb";
            this.jinslb.Size = new System.Drawing.Size(28, 32);
            this.jinslb.TabIndex = 36;
            this.jinslb.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(56, 673);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 32);
            this.label12.TabIndex = 36;
            this.label12.Text = "Manzili:";
            // 
            // kasblb
            // 
            this.kasblb.AutoSize = true;
            this.kasblb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kasblb.Location = new System.Drawing.Point(210, 579);
            this.kasblb.Name = "kasblb";
            this.kasblb.Size = new System.Drawing.Size(28, 32);
            this.kasblb.TabIndex = 36;
            this.kasblb.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(56, 641);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 32);
            this.label9.TabIndex = 36;
            this.label9.Text = "Millati:";
            // 
            // familiyalb
            // 
            this.familiyalb.AutoSize = true;
            this.familiyalb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.familiyalb.Location = new System.Drawing.Point(210, 451);
            this.familiyalb.Name = "familiyalb";
            this.familiyalb.Size = new System.Drawing.Size(28, 32);
            this.familiyalb.TabIndex = 36;
            this.familiyalb.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(56, 608);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 32);
            this.label14.TabIndex = 36;
            this.label14.Text = "Jinsi:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(56, 579);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 32);
            this.label8.TabIndex = 36;
            this.label8.Text = "Kasbi:";
            // 
            // ismlb
            // 
            this.ismlb.AutoSize = true;
            this.ismlb.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ismlb.Location = new System.Drawing.Point(210, 419);
            this.ismlb.Name = "ismlb";
            this.ismlb.Size = new System.Drawing.Size(28, 32);
            this.ismlb.TabIndex = 36;
            this.ismlb.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(56, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 32);
            this.label1.TabIndex = 36;
            this.label1.Text = "Ismi:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(463, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(218, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(598, 92);
            this.label4.TabIndex = 34;
            this.label4.Text = "O\'zbekiston Respublikasi Fuqarosi\r\n\r\n";
            // 
            // qrcodebox
            // 
            this.qrcodebox.Location = new System.Drawing.Point(655, 695);
            this.qrcodebox.Name = "qrcodebox";
            this.qrcodebox.Size = new System.Drawing.Size(278, 289);
            this.qrcodebox.TabIndex = 33;
            this.qrcodebox.TabStop = false;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BorderRadius = 10;
            this.guna2PictureBox1.Image = global::Kurs_ishi.Properties.Resources.user;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(686, 325);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(247, 221);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 29;
            this.guna2PictureBox1.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(25, 5);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(10, 10);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            this.richTextBox1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // qrbtn
            // 
            this.qrbtn.Image = global::Kurs_ishi.Properties.Resources.qr_code__1_;
            this.qrbtn.Location = new System.Drawing.Point(88, -2);
            this.qrbtn.Name = "qrbtn";
            this.qrbtn.Size = new System.Drawing.Size(69, 53);
            this.qrbtn.TabIndex = 1;
            this.qrbtn.UseVisualStyleBackColor = true;
            this.qrbtn.Click += new System.EventHandler(this.qrbtn_Click);
            // 
            // button1
            // 
            this.button1.Image = global::Kurs_ishi.Properties.Resources.printer__1_;
            this.button1.Location = new System.Drawing.Point(0, -2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 53);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Chop_etish
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(945, 1050);
            this.Controls.Add(this.qrbtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Chop_etish";
            this.Text = "Chop_etish";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Chop_etish_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qrcodebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox qrcodebox;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label yoshlb;
        private System.Windows.Forms.Label familiyalb;
        private System.Windows.Forms.Label ismlb;
        private System.Windows.Forms.Label todaylb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label emaillb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label tellb;
        private System.Windows.Forms.Label jinslb;
        private System.Windows.Forms.Label kasblb;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label manzillb;
        private System.Windows.Forms.Label millatlb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button qrbtn;
    }
}