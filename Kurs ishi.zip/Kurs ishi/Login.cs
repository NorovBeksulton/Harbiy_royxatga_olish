﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kurs_ishi
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private SqlConnection con;
        private Admin admin;
        private Asosiy form1;
        private Forgotpasword form;
        private void Login_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kurs"].ConnectionString);

            con.Open();
            panel3.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter(
           "select count(*) from Login where Login='" + Logintxt.Text + "' and Parol='" + Paroltxt.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            SqlDataAdapter da = new SqlDataAdapter(
            "select count(*) from Admin where Login='" + Logintxt.Text + "' and Parol='" + Paroltxt.Text + "'", con);
            DataTable dat = new DataTable();
            da.Fill(dat);

            if (Logintxt.Text == string.Empty && Paroltxt.Text == string.Empty)
            {
                MessageBox.Show("Login yoki parolni kiriting!");
            }
            else
            {
                if (dat.Rows[0][0].ToString() == "1")
                {

                    if (admin == null || admin.IsDisposed)
                    {
                        admin = new Admin();
                        admin.Show();
                        this.Hide();
                        Logintxt.Clear();
                        Paroltxt.Clear();
                    }
                    else
                    {
                        admin.Focus();
                    }
                }
                else if (dt.Rows[0][0].ToString() == "1")
                {
                    if (form1 == null || form1.IsDisposed)
                    {
                        form1 = new Asosiy();
                        form1.Show();
                        this.Hide();
                        Logintxt.Clear();
                        Paroltxt.Clear();
                    }
                    else
                    {
                        form1.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Siz kiritgan login yoki parol noto'g'ri");

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            panel1.Visible = false;
            orqabtn.Visible = true;
            Logintxt.Clear(); Paroltxt.Clear();
        }

        private void orqabtn_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel1.Visible = true;
            orqabtn.Visible = false;
            ismbox.Clear(); loginbox.Clear(); parolbox.Clear(); emailbox.Clear();
        }

        private void kirishbtn_Click(object sender, EventArgs e)
        {
            if (loginbox.Text == string.Empty || parolbox.Text == string.Empty || emailbox.Text == string.Empty || ismbox.Text == string.Empty)
            {
                MessageBox.Show("Ma'lumotlarni to'liq kiriting!");
            }
            else
            {
                DataTable dt = new DataTable("Login", "Login,Email");

                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Bunday foydalanuvchi oldindan mavjud!", "Eslatma", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand($"INSERT INTO [Login] (Ism,Login,Parol,Email) VALUES (@Ism,@Login,@Parol,@Email)",
                           con);

                        cmd.Parameters.AddWithValue("Ism", ismbox.Text);
                        cmd.Parameters.AddWithValue("Login", loginbox.Text);
                        cmd.Parameters.AddWithValue("Parol", parolbox.Text);
                        cmd.Parameters.AddWithValue("Email", emailbox.Text);
                        cmd.ExecuteNonQuery().ToString();
                        MessageBox.Show("Muvafaqiyatli o'tdingiz! ");
                        panel3.Visible = false;
                        panel1.Visible = true;
                        orqabtn.Visible = false;
                        ismbox.Clear(); loginbox.Clear(); parolbox.Clear(); emailbox.Clear();

                    }
                    catch
                    {
                        MessageBox.Show("Iltimos ma'lumotlarni to'liq kiriting!");
                    }
                }

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (form == null || form.IsDisposed)
            {
                form = new Forgotpasword();
                form.Show();
                this.Hide();
                Logintxt.Clear();
                Paroltxt.Clear();
            }
            else
            {
                form.Focus();
            }
        }

        private void Paroltxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SqlDataAdapter sda = new SqlDataAdapter(
                "select count(*) from Login where Login='" + Logintxt.Text + "' and Parol='" + Paroltxt.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                SqlDataAdapter da = new SqlDataAdapter(
                "select count(*) from Admin where Login='" + Logintxt.Text + "' and Parol='" + Paroltxt.Text + "'", con);
                DataTable dat = new DataTable();
                da.Fill(dat);

                if (Logintxt.Text == string.Empty && Paroltxt.Text == string.Empty)
                {
                    MessageBox.Show("Login yoki parolni kiriting!");
                }
                else
                {
                    if (dat.Rows[0][0].ToString() == "1")
                    {

                        if (admin == null || admin.IsDisposed)
                        {
                            admin = new Admin();
                            admin.Show();
                            this.Hide();
                            Logintxt.Clear();
                            Paroltxt.Clear();
                        }
                        else
                        {
                            admin.Focus();
                        }
                    }
                    else if (dt.Rows[0][0].ToString() == "1")
                    {
                        if (form1 == null || form1.IsDisposed)
                        {
                            form1 = new Asosiy();
                            form1.Show();
                            this.Hide();
                            Logintxt.Clear();
                            Paroltxt.Clear();
                        }
                        else
                        {
                            form1.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Siz kiritgan login yoki parol noto'g'ri");

                    }
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void eyebtn_MouseDown(object sender, MouseEventArgs e)
        {
            Paroltxt.PasswordChar = '\0';
        }

        private void eyebtn_MouseUp(object sender, MouseEventArgs e)
        {
            Paroltxt.PasswordChar = '●';
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            parolbox.PasswordChar = '\0';
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            parolbox.PasswordChar = '●';
        }
    }
}
