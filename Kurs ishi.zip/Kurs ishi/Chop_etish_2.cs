﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;
using Panel = System.Windows.Forms.Panel;
namespace Kurs_ishi
{
    public partial class Chop_etish_2 : Form
    {
        public Chop_etish_2()
        {
            InitializeComponent();
        }
        private Bitmap bp;
        public string Ism, Familiya, Sharif,Yoshi, Jinsi, Tashxis, Yuborilganjoy, Unvoni, Manzil;

        public System.Drawing.Image Img;
        private void qrbtn_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "Ismi: " + ismlb.Text + "\n" + "Familiyasi: " + familiyalb.Text + "\n" + "Yoshi: " + yoshlb.Text + "\n" + "Jinsi: " + jinslb.Text + "\n" + "Manzil: " + manzillb.Text + "\n" + "Tashxis: " + tellb.Text;

            QRCoder.QRCodeGenerator qr = new QRCoder.QRCodeGenerator();
            var qrdata = qr.CreateQrCode(richTextBox1.Text, QRCoder.QRCodeGenerator.ECCLevel.Q);
            var qrcode = new QRCoder.QRCode(qrdata);

            qrcodebox.Image = qrcode.GetGraphic(3);
            button1.Enabled = true;
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle rectangle = e.PageBounds;
            e.Graphics.DrawImage(bp, rectangle.Width / 2 - this.panel1.Width / 4, this.panel1.Location.Y + 10);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Print(panel1);
            button1.Enabled = false;
        }

        private void Chop_etish_2_Load(object sender, EventArgs e)
        {
            todaylb.Text = DateTime.Now.ToString("MM/dd/yyyy");
            ismlb.Text = Ism;
            familiyalb.Text = Familiya;
            yoshlb.Text=Yoshi;
            jinslb.Text = Jinsi;
            tellb.Text = Tashxis;
            shariflbl.Text = Sharif;
            manzillb.Text = Yuborilganjoy;
            millatlb.Text = Unvoni;
            guna2PictureBox1.Image = Img;
            button1.Enabled = false;
        }
        private void Print(Panel panel)
        {
            PrinterSettings ps = new PrinterSettings();
            panel1 = panel;
            getprintarea(panel);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();

        }
        private void getprintarea(Panel panel)
        {
            bp = new Bitmap(panel.Width, panel.Height);
            panel.DrawToBitmap(bp, new Rectangle(0, 0, panel1.Width, panel1.Height));
        }
    }
}
