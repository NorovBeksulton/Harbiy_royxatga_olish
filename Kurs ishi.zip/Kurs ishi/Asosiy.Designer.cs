﻿namespace Kurs_ishi
{
    partial class Asosiy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Asosiy));
            this.menuTimer = new System.Windows.Forms.Timer(this.components);
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Munebutton = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.settingsbtn = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.aboutbtn = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.helpbtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.homebtn = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.qushbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.tahrirbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.delbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.printbtn2 = new Guna.UI2.WinForms.Guna2Button();
            this.fuqarolarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qabul_panel = new System.Windows.Forms.Panel();
            this.qidirbtn = new Guna.UI2.WinForms.Guna2Button();
            this.rasmbtn = new System.Windows.Forms.Button();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.deletebtn = new Guna.UI2.WinForms.Guna2Button();
            this.printbtn = new Guna.UI2.WinForms.Guna2Button();
            this.refreshbtn = new Guna.UI2.WinForms.Guna2Button();
            this.tozabtn = new Guna.UI2.WinForms.Guna2Button();
            this.editbtn = new Guna.UI2.WinForms.Guna2Button();
            this.savebtn = new Guna.UI2.WinForms.Guna2Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ismDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familiyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sharifiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yoshiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kasbiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jinsiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.millatiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manziliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.joindateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuqarolarBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet11 = new Kurs_ishi.Kurs_ishiDataSet11();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.datalbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.birthtxt = new System.Windows.Forms.MaskedTextBox();
            this.millattxt = new System.Windows.Forms.ComboBox();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.telefontxt = new System.Windows.Forms.TextBox();
            this.yoshtxt = new System.Windows.Forms.TextBox();
            this.kasbtxt = new System.Windows.Forms.TextBox();
            this.shariftxt1 = new System.Windows.Forms.TextBox();
            this.familiyatxt = new System.Windows.Forms.TextBox();
            this.ismitxt = new System.Windows.Forms.TextBox();
            this.manziltxt = new System.Windows.Forms.RichTextBox();
            this.qidirtxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.fuqarolarBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet8 = new Kurs_ishi.Kurs_ishiDataSet8();
            this.qabul2_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.tashxistxt = new System.Windows.Forms.ComboBox();
            this.xizmat = new System.Windows.Forms.ComboBox();
            this.kontrakt = new System.Windows.Forms.ComboBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tozabtn2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.refbtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label17 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.vaznitxt2 = new System.Windows.Forms.TextBox();
            this.boyitxt = new System.Windows.Forms.TextBox();
            this.unvon = new System.Windows.Forms.TextBox();
            this.yoshtxt2 = new System.Windows.Forms.TextBox();
            this.shariftxt = new System.Windows.Forms.TextBox();
            this.familiya2txt = new System.Windows.Forms.TextBox();
            this.ism2txt = new System.Windows.Forms.TextBox();
            this.guna2DataGridView3 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2DataGridView2 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ismDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Familiya = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sharifDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yoshDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.boyiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vazniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tashxisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xizmatTuriDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chaqirilganlarBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet7 = new Kurs_ishi.Kurs_ishiDataSet7();
            this.fuqarolarBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet3 = new Kurs_ishi.Kurs_ishiDataSet3();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.chaqirilganlarBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet6 = new Kurs_ishi.Kurs_ishiDataSet6();
            this.chaqirilganlarBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.kurs_ishiDataSet4 = new Kurs_ishi.Kurs_ishiDataSet4();
            this.sozlamalar_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.adminuzpanel = new System.Windows.Forms.Panel();
            this.uzgarbtn = new Guna.UI2.WinForms.Guna2Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.kunbtn = new Guna.UI2.WinForms.Guna2Button();
            this.tunbtn = new Guna.UI2.WinForms.Guna2Button();
            this.kurs_ishiDataSet2 = new Kurs_ishi.Kurs_ishiDataSet2();
            this.chaqirilganlarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chaqirilganlarTableAdapter = new Kurs_ishi.Kurs_ishiDataSet2TableAdapters.ChaqirilganlarTableAdapter();
            this.fuqarolarTableAdapter1 = new Kurs_ishi.Kurs_ishiDataSet3TableAdapters.FuqarolarTableAdapter();
            this.chaqirilganlarTableAdapter1 = new Kurs_ishi.Kurs_ishiDataSet4TableAdapters.ChaqirilganlarTableAdapter();
            this.chaqirilganlarTableAdapter3 = new Kurs_ishi.Kurs_ishiDataSet6TableAdapters.ChaqirilganlarTableAdapter();
            this.kurs_ishiDataSet5 = new Kurs_ishi.Kurs_ishiDataSet5();
            this.chaqirilganlarTableAdapter2 = new Kurs_ishi.Kurs_ishiDataSet7TableAdapters.ChaqirilganlarTableAdapter();
            this.fuqarolarTableAdapter2 = new Kurs_ishi.Kurs_ishiDataSet8TableAdapters.FuqarolarTableAdapter();
            this.chaqirilganlarBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.fuqarolarTableAdapter3 = new Kurs_ishi.Kurs_ishiDataSet11TableAdapters.FuqarolarTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Munebutton)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource)).BeginInit();
            this.qabul_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet8)).BeginInit();
            this.qabul2_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet4)).BeginInit();
            this.sozlamalar_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.adminuzpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuTimer
            // 
            this.menuTimer.Interval = 10;
            this.menuTimer.Tick += new System.EventHandler(this.menuTimer_Tick);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Black;
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.panel9);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.panel5);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel8);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.MaximumSize = new System.Drawing.Size(255, 1200);
            this.flowLayoutPanel1.MinimumSize = new System.Drawing.Size(60, 1200);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(255, 1200);
            this.flowLayoutPanel1.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.Munebutton);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(252, 190);
            this.panel3.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(55, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Menu";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Munebutton
            // 
            this.Munebutton.Image = global::Kurs_ishi.Properties.Resources.list;
            this.Munebutton.Location = new System.Drawing.Point(3, 9);
            this.Munebutton.Name = "Munebutton";
            this.Munebutton.Size = new System.Drawing.Size(46, 39);
            this.Munebutton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Munebutton.TabIndex = 0;
            this.Munebutton.TabStop = false;
            this.Munebutton.Click += new System.EventHandler(this.Munebutton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(3, 199);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(252, 51);
            this.panel1.TabIndex = 15;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Kurs_ishi.Properties.Resources.kyc;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 51);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(43, -11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(217, 73);
            this.button1.TabIndex = 11;
            this.button1.Text = "  Fuqarolar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.pictureBox8);
            this.panel9.Controls.Add(this.button4);
            this.panel9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel9.Location = new System.Drawing.Point(3, 256);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(252, 51);
            this.panel9.TabIndex = 15;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Kurs_ishi.Properties.Resources.accept;
            this.pictureBox8.Location = new System.Drawing.Point(0, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(49, 51);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 12;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(43, -13);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(217, 73);
            this.button4.TabIndex = 11;
            this.button4.Text = "  Qabul qilish";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.settingsbtn);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(3, 313);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(252, 51);
            this.panel4.TabIndex = 13;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Kurs_ishi.Properties.Resources.settings;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 51);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // settingsbtn
            // 
            this.settingsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsbtn.ForeColor = System.Drawing.Color.White;
            this.settingsbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.settingsbtn.Location = new System.Drawing.Point(43, -11);
            this.settingsbtn.Name = "settingsbtn";
            this.settingsbtn.Size = new System.Drawing.Size(217, 73);
            this.settingsbtn.TabIndex = 11;
            this.settingsbtn.Text = "   Sozlamalar";
            this.settingsbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.settingsbtn.UseVisualStyleBackColor = true;
            this.settingsbtn.Click += new System.EventHandler(this.settingsbtn_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Controls.Add(this.aboutbtn);
            this.panel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel6.Location = new System.Drawing.Point(3, 370);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(252, 51);
            this.panel6.TabIndex = 13;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Kurs_ishi.Properties.Resources.information;
            this.pictureBox6.Location = new System.Drawing.Point(0, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(49, 51);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // aboutbtn
            // 
            this.aboutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aboutbtn.ForeColor = System.Drawing.Color.White;
            this.aboutbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.aboutbtn.Location = new System.Drawing.Point(43, -11);
            this.aboutbtn.Name = "aboutbtn";
            this.aboutbtn.Size = new System.Drawing.Size(217, 73);
            this.aboutbtn.TabIndex = 11;
            this.aboutbtn.Text = "  Statistika";
            this.aboutbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.aboutbtn.UseVisualStyleBackColor = true;
            this.aboutbtn.Click += new System.EventHandler(this.aboutbtn_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.helpbtn);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(3, 427);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(252, 51);
            this.panel5.TabIndex = 14;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Kurs_ishi.Properties.Resources.help;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 51);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // helpbtn
            // 
            this.helpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.helpbtn.ForeColor = System.Drawing.Color.White;
            this.helpbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.helpbtn.Location = new System.Drawing.Point(43, -11);
            this.helpbtn.Name = "helpbtn";
            this.helpbtn.Size = new System.Drawing.Size(217, 73);
            this.helpbtn.TabIndex = 11;
            this.helpbtn.Text = "   Yordam";
            this.helpbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.helpbtn.UseVisualStyleBackColor = true;
            this.helpbtn.Click += new System.EventHandler(this.helpbtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.homebtn);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(3, 484);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 51);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Kurs_ishi.Properties.Resources.home_button;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 51);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // homebtn
            // 
            this.homebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homebtn.ForeColor = System.Drawing.Color.White;
            this.homebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.homebtn.Location = new System.Drawing.Point(43, -11);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(217, 73);
            this.homebtn.TabIndex = 11;
            this.homebtn.Text = "   Login";
            this.homebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.homebtn.UseVisualStyleBackColor = true;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.pictureBox7);
            this.panel8.Controls.Add(this.button3);
            this.panel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel8.Location = new System.Drawing.Point(3, 541);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(252, 51);
            this.panel8.TabIndex = 13;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Kurs_ishi.Properties.Resources.logout;
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(49, 51);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(43, -11);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(217, 73);
            this.button3.TabIndex = 11;
            this.button3.Text = "   Chiqish";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // qushbtn
            // 
            this.qushbtn.BorderRadius = 10;
            this.qushbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.qushbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.qushbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.qushbtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.qushbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.qushbtn.FillColor = System.Drawing.Color.GreenYellow;
            this.qushbtn.FillColor2 = System.Drawing.Color.GreenYellow;
            this.qushbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.qushbtn.ForeColor = System.Drawing.Color.White;
            this.qushbtn.Location = new System.Drawing.Point(215, 712);
            this.qushbtn.Name = "qushbtn";
            this.qushbtn.Size = new System.Drawing.Size(155, 51);
            this.qushbtn.TabIndex = 66;
            this.qushbtn.Text = "Qo\'shish";
            this.qushbtn.Click += new System.EventHandler(this.qushbtn_Click);
            // 
            // tahrirbtn
            // 
            this.tahrirbtn.BorderRadius = 10;
            this.tahrirbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tahrirbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tahrirbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tahrirbtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tahrirbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tahrirbtn.FillColor = System.Drawing.Color.Silver;
            this.tahrirbtn.FillColor2 = System.Drawing.Color.Gray;
            this.tahrirbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.tahrirbtn.ForeColor = System.Drawing.Color.White;
            this.tahrirbtn.Location = new System.Drawing.Point(410, 712);
            this.tahrirbtn.Name = "tahrirbtn";
            this.tahrirbtn.Size = new System.Drawing.Size(155, 51);
            this.tahrirbtn.TabIndex = 67;
            this.tahrirbtn.Text = "Tahrirlash";
            this.tahrirbtn.Click += new System.EventHandler(this.tahrirbtn_Click);
            // 
            // delbtn
            // 
            this.delbtn.BorderRadius = 10;
            this.delbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.delbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.delbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.delbtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.delbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.delbtn.FillColor = System.Drawing.Color.Red;
            this.delbtn.FillColor2 = System.Drawing.Color.Red;
            this.delbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.delbtn.ForeColor = System.Drawing.Color.White;
            this.delbtn.Location = new System.Drawing.Point(593, 716);
            this.delbtn.Name = "delbtn";
            this.delbtn.Size = new System.Drawing.Size(155, 47);
            this.delbtn.TabIndex = 68;
            this.delbtn.Text = "O\'chirish";
            this.delbtn.Click += new System.EventHandler(this.delbtn_Click);
            // 
            // printbtn2
            // 
            this.printbtn2.BorderRadius = 10;
            this.printbtn2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.printbtn2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.printbtn2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.printbtn2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.printbtn2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.printbtn2.ForeColor = System.Drawing.Color.White;
            this.printbtn2.Location = new System.Drawing.Point(774, 716);
            this.printbtn2.Name = "printbtn2";
            this.printbtn2.Size = new System.Drawing.Size(162, 47);
            this.printbtn2.TabIndex = 69;
            this.printbtn2.Text = "Chop etish";
            this.printbtn2.Click += new System.EventHandler(this.printbtn2_Click);
            // 
            // fuqarolarBindingSource
            // 
            this.fuqarolarBindingSource.DataMember = "Fuqarolar";
            // 
            // qabul_panel
            // 
            this.qabul_panel.BackColor = System.Drawing.Color.White;
            this.qabul_panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.qabul_panel.Controls.Add(this.qidirbtn);
            this.qabul_panel.Controls.Add(this.rasmbtn);
            this.qabul_panel.Controls.Add(this.pictureBox9);
            this.qabul_panel.Controls.Add(this.deletebtn);
            this.qabul_panel.Controls.Add(this.printbtn);
            this.qabul_panel.Controls.Add(this.refreshbtn);
            this.qabul_panel.Controls.Add(this.tozabtn);
            this.qabul_panel.Controls.Add(this.editbtn);
            this.qabul_panel.Controls.Add(this.savebtn);
            this.qabul_panel.Controls.Add(this.radioButton2);
            this.qabul_panel.Controls.Add(this.radioButton1);
            this.qabul_panel.Controls.Add(this.guna2DataGridView1);
            this.qabul_panel.Controls.Add(this.label14);
            this.qabul_panel.Controls.Add(this.label13);
            this.qabul_panel.Controls.Add(this.label12);
            this.qabul_panel.Controls.Add(this.label6);
            this.qabul_panel.Controls.Add(this.label5);
            this.qabul_panel.Controls.Add(this.datalbl);
            this.qabul_panel.Controls.Add(this.label11);
            this.qabul_panel.Controls.Add(this.label4);
            this.qabul_panel.Controls.Add(this.label15);
            this.qabul_panel.Controls.Add(this.label7);
            this.qabul_panel.Controls.Add(this.label29);
            this.qabul_panel.Controls.Add(this.label3);
            this.qabul_panel.Controls.Add(this.label2);
            this.qabul_panel.Controls.Add(this.birthtxt);
            this.qabul_panel.Controls.Add(this.millattxt);
            this.qabul_panel.Controls.Add(this.emailtxt);
            this.qabul_panel.Controls.Add(this.telefontxt);
            this.qabul_panel.Controls.Add(this.yoshtxt);
            this.qabul_panel.Controls.Add(this.kasbtxt);
            this.qabul_panel.Controls.Add(this.shariftxt1);
            this.qabul_panel.Controls.Add(this.familiyatxt);
            this.qabul_panel.Controls.Add(this.ismitxt);
            this.qabul_panel.Controls.Add(this.manziltxt);
            this.qabul_panel.Controls.Add(this.qidirtxt);
            this.qabul_panel.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.qabul_panel.Location = new System.Drawing.Point(336, 12);
            this.qabul_panel.Name = "qabul_panel";
            this.qabul_panel.Size = new System.Drawing.Size(23, 964);
            this.qabul_panel.TabIndex = 9;
            this.qabul_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.qabul_panel_Paint);
            // 
            // qidirbtn
            // 
            this.qidirbtn.BorderRadius = 15;
            this.qidirbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.qidirbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.qidirbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.qidirbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.qidirbtn.FillColor = System.Drawing.Color.White;
            this.qidirbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.qidirbtn.ForeColor = System.Drawing.Color.White;
            this.qidirbtn.Image = global::Kurs_ishi.Properties.Resources.search;
            this.qidirbtn.ImageSize = new System.Drawing.Size(40, 40);
            this.qidirbtn.Location = new System.Drawing.Point(507, 21);
            this.qidirbtn.Name = "qidirbtn";
            this.qidirbtn.Size = new System.Drawing.Size(55, 51);
            this.qidirbtn.TabIndex = 48;
            this.qidirbtn.Click += new System.EventHandler(this.qidirbtn_Click);
            this.qidirbtn.MouseEnter += new System.EventHandler(this.qidirbtn_MouseEnter);
            // 
            // rasmbtn
            // 
            this.rasmbtn.Location = new System.Drawing.Point(1401, 209);
            this.rasmbtn.Name = "rasmbtn";
            this.rasmbtn.Size = new System.Drawing.Size(179, 41);
            this.rasmbtn.TabIndex = 52;
            this.rasmbtn.Text = "Rasm yuklash";
            this.rasmbtn.UseVisualStyleBackColor = true;
            this.rasmbtn.Click += new System.EventHandler(this.rasmbtn_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.DodgerBlue;
            this.pictureBox9.Location = new System.Drawing.Point(1399, 10);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(182, 176);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 51;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.BorderRadius = 15;
            this.deletebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.deletebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.deletebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.deletebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.deletebtn.FillColor = System.Drawing.Color.Red;
            this.deletebtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.deletebtn.ForeColor = System.Drawing.Color.White;
            this.deletebtn.Location = new System.Drawing.Point(637, 639);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(193, 50);
            this.deletebtn.TabIndex = 48;
            this.deletebtn.Text = "O\'chirish";
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // printbtn
            // 
            this.printbtn.BorderRadius = 15;
            this.printbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.printbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.printbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.printbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.printbtn.FillColor = System.Drawing.Color.Gold;
            this.printbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.printbtn.ForeColor = System.Drawing.Color.White;
            this.printbtn.Location = new System.Drawing.Point(1355, 639);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(193, 50);
            this.printbtn.TabIndex = 48;
            this.printbtn.Text = "Chop etish";
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // refreshbtn
            // 
            this.refreshbtn.BorderRadius = 15;
            this.refreshbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.refreshbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.refreshbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refreshbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.refreshbtn.FillColor = System.Drawing.Color.MediumBlue;
            this.refreshbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.refreshbtn.ForeColor = System.Drawing.Color.White;
            this.refreshbtn.Location = new System.Drawing.Point(1123, 639);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(193, 50);
            this.refreshbtn.TabIndex = 48;
            this.refreshbtn.Text = "Yangilash";
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // tozabtn
            // 
            this.tozabtn.BorderRadius = 15;
            this.tozabtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tozabtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tozabtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tozabtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tozabtn.FillColor = System.Drawing.Color.Orange;
            this.tozabtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tozabtn.ForeColor = System.Drawing.Color.White;
            this.tozabtn.Location = new System.Drawing.Point(891, 639);
            this.tozabtn.Name = "tozabtn";
            this.tozabtn.Size = new System.Drawing.Size(193, 50);
            this.tozabtn.TabIndex = 48;
            this.tozabtn.Text = "Tozalash";
            this.tozabtn.Click += new System.EventHandler(this.tozabtn_Click);
            // 
            // editbtn
            // 
            this.editbtn.BorderRadius = 15;
            this.editbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.editbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.editbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.editbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.editbtn.FillColor = System.Drawing.Color.DodgerBlue;
            this.editbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editbtn.ForeColor = System.Drawing.Color.White;
            this.editbtn.Location = new System.Drawing.Point(386, 639);
            this.editbtn.Name = "editbtn";
            this.editbtn.Size = new System.Drawing.Size(193, 50);
            this.editbtn.TabIndex = 48;
            this.editbtn.Text = "Tahrirlash:";
            this.editbtn.Click += new System.EventHandler(this.editbtn_Click);
            // 
            // savebtn
            // 
            this.savebtn.BorderRadius = 15;
            this.savebtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savebtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savebtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savebtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savebtn.FillColor = System.Drawing.Color.ForestGreen;
            this.savebtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebtn.ForeColor = System.Drawing.Color.White;
            this.savebtn.Location = new System.Drawing.Point(133, 639);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(193, 50);
            this.savebtn.TabIndex = 12;
            this.savebtn.Text = "Qo\'shish";
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(306, 553);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 27);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Ayol";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(306, 520);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(88, 27);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Erkak";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // guna2DataGridView1
            // 
            this.guna2DataGridView1.AllowUserToAddRows = false;
            this.guna2DataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.guna2DataGridView1.AutoGenerateColumns = false;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.guna2DataGridView1.ColumnHeadersHeight = 22;
            this.guna2DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.ismDataGridViewTextBoxColumn,
            this.familiyaDataGridViewTextBoxColumn,
            this.sharifiDataGridViewTextBoxColumn,
            this.yoshiDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.kasbiDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.jinsiDataGridViewTextBoxColumn,
            this.millatiDataGridViewTextBoxColumn,
            this.manziliDataGridViewTextBoxColumn,
            this.joindateDataGridViewTextBoxColumn});
            this.guna2DataGridView1.DataSource = this.fuqarolarBindingSource3;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle21;
            this.guna2DataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(0, 651);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.ReadOnly = true;
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 62;
            this.guna2DataGridView1.RowTemplate.Height = 28;
            this.guna2DataGridView1.Size = new System.Drawing.Size(19, 309);
            this.guna2DataGridView1.TabIndex = 46;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 22;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 28;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellContentClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ismDataGridViewTextBoxColumn
            // 
            this.ismDataGridViewTextBoxColumn.DataPropertyName = "Ism";
            this.ismDataGridViewTextBoxColumn.HeaderText = "Ism";
            this.ismDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.ismDataGridViewTextBoxColumn.Name = "ismDataGridViewTextBoxColumn";
            this.ismDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // familiyaDataGridViewTextBoxColumn
            // 
            this.familiyaDataGridViewTextBoxColumn.DataPropertyName = "Familiya";
            this.familiyaDataGridViewTextBoxColumn.HeaderText = "Familiya";
            this.familiyaDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.familiyaDataGridViewTextBoxColumn.Name = "familiyaDataGridViewTextBoxColumn";
            this.familiyaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sharifiDataGridViewTextBoxColumn
            // 
            this.sharifiDataGridViewTextBoxColumn.DataPropertyName = "Sharifi";
            this.sharifiDataGridViewTextBoxColumn.HeaderText = "Sharifi";
            this.sharifiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.sharifiDataGridViewTextBoxColumn.Name = "sharifiDataGridViewTextBoxColumn";
            this.sharifiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yoshiDataGridViewTextBoxColumn
            // 
            this.yoshiDataGridViewTextBoxColumn.DataPropertyName = "Yoshi";
            this.yoshiDataGridViewTextBoxColumn.HeaderText = "Yoshi";
            this.yoshiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.yoshiDataGridViewTextBoxColumn.Name = "yoshiDataGridViewTextBoxColumn";
            this.yoshiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            this.birthdayDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kasbiDataGridViewTextBoxColumn
            // 
            this.kasbiDataGridViewTextBoxColumn.DataPropertyName = "Kasbi";
            this.kasbiDataGridViewTextBoxColumn.HeaderText = "Kasbi";
            this.kasbiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.kasbiDataGridViewTextBoxColumn.Name = "kasbiDataGridViewTextBoxColumn";
            this.kasbiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "Telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "Telefon";
            this.telefonDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            this.telefonDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jinsiDataGridViewTextBoxColumn
            // 
            this.jinsiDataGridViewTextBoxColumn.DataPropertyName = "Jinsi";
            this.jinsiDataGridViewTextBoxColumn.HeaderText = "Jinsi";
            this.jinsiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.jinsiDataGridViewTextBoxColumn.Name = "jinsiDataGridViewTextBoxColumn";
            this.jinsiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // millatiDataGridViewTextBoxColumn
            // 
            this.millatiDataGridViewTextBoxColumn.DataPropertyName = "Millati";
            this.millatiDataGridViewTextBoxColumn.HeaderText = "Millati";
            this.millatiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.millatiDataGridViewTextBoxColumn.Name = "millatiDataGridViewTextBoxColumn";
            this.millatiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // manziliDataGridViewTextBoxColumn
            // 
            this.manziliDataGridViewTextBoxColumn.DataPropertyName = "Manzili";
            this.manziliDataGridViewTextBoxColumn.HeaderText = "Manzili";
            this.manziliDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manziliDataGridViewTextBoxColumn.Name = "manziliDataGridViewTextBoxColumn";
            this.manziliDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // joindateDataGridViewTextBoxColumn
            // 
            this.joindateDataGridViewTextBoxColumn.DataPropertyName = "Joindate";
            this.joindateDataGridViewTextBoxColumn.HeaderText = "Joindate";
            this.joindateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.joindateDataGridViewTextBoxColumn.Name = "joindateDataGridViewTextBoxColumn";
            this.joindateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fuqarolarBindingSource3
            // 
            this.fuqarolarBindingSource3.DataMember = "Fuqarolar";
            this.fuqarolarBindingSource3.DataSource = this.kurs_ishiDataSet11;
            // 
            // kurs_ishiDataSet11
            // 
            this.kurs_ishiDataSet11.DataSetName = "Kurs_ishiDataSet11";
            this.kurs_ishiDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(818, 144);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 23);
            this.label14.TabIndex = 44;
            this.label14.Text = "Manzili:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(826, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 23);
            this.label13.TabIndex = 42;
            this.label13.Text = "Millati:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(137, 347);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 23);
            this.label12.TabIndex = 41;
            this.label12.Text = "Kasbi:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(136, 524);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 23);
            this.label6.TabIndex = 40;
            this.label6.Text = "Jinsi:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(136, 298);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 23);
            this.label5.TabIndex = 39;
            this.label5.Text = "Tug\'ulgan sanasi:";
            // 
            // datalbl
            // 
            this.datalbl.AutoSize = true;
            this.datalbl.Location = new System.Drawing.Point(959, 224);
            this.datalbl.Name = "datalbl";
            this.datalbl.Size = new System.Drawing.Size(20, 23);
            this.datalbl.TabIndex = 38;
            this.datalbl.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(592, 218);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(306, 23);
            this.label11.TabIndex = 38;
            this.label11.Text = "Ro\'yxatdan o\'tkazilayotgan sanasi:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(136, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 23);
            this.label4.TabIndex = 37;
            this.label4.Text = "Yoshi:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(136, 455);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 23);
            this.label15.TabIndex = 35;
            this.label15.Text = "Emaili:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(136, 398);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 23);
            this.label7.TabIndex = 45;
            this.label7.Text = "Telefon raqami:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(135, 197);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 23);
            this.label29.TabIndex = 33;
            this.label29.Text = "Sharifi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(136, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 23);
            this.label3.TabIndex = 33;
            this.label3.Text = "Familiyasi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 23);
            this.label2.TabIndex = 32;
            this.label2.Text = "Ismi:";
            // 
            // birthtxt
            // 
            this.birthtxt.Location = new System.Drawing.Point(307, 295);
            this.birthtxt.Mask = "00/00/0000";
            this.birthtxt.Name = "birthtxt";
            this.birthtxt.Size = new System.Drawing.Size(254, 30);
            this.birthtxt.TabIndex = 5;
            this.birthtxt.ValidatingType = typeof(System.DateTime);
            // 
            // millattxt
            // 
            this.millattxt.FormattingEnabled = true;
            this.millattxt.Items.AddRange(new object[] {
            "O\'zbek",
            "Tojik",
            "Qirg\'iz",
            "Qozoq",
            "Turkman",
            "Turk",
            "Rus"});
            this.millattxt.Location = new System.Drawing.Point(941, 77);
            this.millattxt.Name = "millattxt";
            this.millattxt.Size = new System.Drawing.Size(291, 31);
            this.millattxt.TabIndex = 29;
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(306, 455);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(255, 30);
            this.emailtxt.TabIndex = 8;
            // 
            // telefontxt
            // 
            this.telefontxt.Location = new System.Drawing.Point(306, 398);
            this.telefontxt.Name = "telefontxt";
            this.telefontxt.Size = new System.Drawing.Size(255, 30);
            this.telefontxt.TabIndex = 7;
            this.telefontxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.telefontxt_KeyPress);
            // 
            // yoshtxt
            // 
            this.yoshtxt.Location = new System.Drawing.Point(307, 242);
            this.yoshtxt.Name = "yoshtxt";
            this.yoshtxt.Size = new System.Drawing.Size(255, 30);
            this.yoshtxt.TabIndex = 4;
            this.yoshtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.yoshtxt_KeyPress);
            // 
            // kasbtxt
            // 
            this.kasbtxt.Location = new System.Drawing.Point(308, 343);
            this.kasbtxt.Name = "kasbtxt";
            this.kasbtxt.Size = new System.Drawing.Size(253, 30);
            this.kasbtxt.TabIndex = 6;
            // 
            // shariftxt1
            // 
            this.shariftxt1.Location = new System.Drawing.Point(306, 196);
            this.shariftxt1.Name = "shariftxt1";
            this.shariftxt1.Size = new System.Drawing.Size(255, 30);
            this.shariftxt1.TabIndex = 3;
            // 
            // familiyatxt
            // 
            this.familiyatxt.Location = new System.Drawing.Point(307, 153);
            this.familiyatxt.Name = "familiyatxt";
            this.familiyatxt.Size = new System.Drawing.Size(255, 30);
            this.familiyatxt.TabIndex = 2;
            // 
            // ismitxt
            // 
            this.ismitxt.Location = new System.Drawing.Point(308, 102);
            this.ismitxt.Name = "ismitxt";
            this.ismitxt.Size = new System.Drawing.Size(255, 30);
            this.ismitxt.TabIndex = 1;
            // 
            // manziltxt
            // 
            this.manziltxt.Location = new System.Drawing.Point(941, 144);
            this.manziltxt.Name = "manziltxt";
            this.manziltxt.Size = new System.Drawing.Size(291, 35);
            this.manziltxt.TabIndex = 11;
            this.manziltxt.Text = "";
            // 
            // qidirtxt
            // 
            this.qidirtxt.BorderColor = System.Drawing.Color.Black;
            this.qidirtxt.BorderRadius = 10;
            this.qidirtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qidirtxt.DefaultText = "";
            this.qidirtxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.qidirtxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.qidirtxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qidirtxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.qidirtxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qidirtxt.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.qidirtxt.ForeColor = System.Drawing.Color.Black;
            this.qidirtxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.qidirtxt.Location = new System.Drawing.Point(182, 14);
            this.qidirtxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.qidirtxt.Name = "qidirtxt";
            this.qidirtxt.PasswordChar = '\0';
            this.qidirtxt.PlaceholderText = "Qidirish";
            this.qidirtxt.SelectedText = "";
            this.qidirtxt.Size = new System.Drawing.Size(425, 63);
            this.qidirtxt.TabIndex = 49;
            this.qidirtxt.TextChanged += new System.EventHandler(this.qidirtxt_TextChanged);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(65, 844);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(94, 42);
            this.button7.TabIndex = 54;
            this.button7.Text = "Send";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // fuqarolarBindingSource2
            // 
            this.fuqarolarBindingSource2.DataMember = "Fuqarolar";
            this.fuqarolarBindingSource2.DataSource = this.kurs_ishiDataSet8;
            // 
            // kurs_ishiDataSet8
            // 
            this.kurs_ishiDataSet8.DataSetName = "Kurs_ishiDataSet8";
            this.kurs_ishiDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // qabul2_panel
            // 
            this.qabul2_panel.BackColor = System.Drawing.Color.Transparent;
            this.qabul2_panel.Controls.Add(this.comboBox1);
            this.qabul2_panel.Controls.Add(this.button2);
            this.qabul2_panel.Controls.Add(this.pictureBox2);
            this.qabul2_panel.Controls.Add(this.guna2Button2);
            this.qabul2_panel.Controls.Add(this.guna2TextBox1);
            this.qabul2_panel.Controls.Add(this.tashxistxt);
            this.qabul2_panel.Controls.Add(this.xizmat);
            this.qabul2_panel.Controls.Add(this.kontrakt);
            this.qabul2_panel.Controls.Add(this.radioButton3);
            this.qabul2_panel.Controls.Add(this.radioButton4);
            this.qabul2_panel.Controls.Add(this.label27);
            this.qabul2_panel.Controls.Add(this.label21);
            this.qabul2_panel.Controls.Add(this.label16);
            this.qabul2_panel.Controls.Add(this.qushbtn);
            this.qabul2_panel.Controls.Add(this.tahrirbtn);
            this.qabul2_panel.Controls.Add(this.tozabtn2);
            this.qabul2_panel.Controls.Add(this.delbtn);
            this.qabul2_panel.Controls.Add(this.refbtn);
            this.qabul2_panel.Controls.Add(this.printbtn2);
            this.qabul2_panel.Controls.Add(this.label17);
            this.qabul2_panel.Controls.Add(this.label28);
            this.qabul2_panel.Controls.Add(this.label22);
            this.qabul2_panel.Controls.Add(this.label23);
            this.qabul2_panel.Controls.Add(this.label20);
            this.qabul2_panel.Controls.Add(this.label24);
            this.qabul2_panel.Controls.Add(this.label25);
            this.qabul2_panel.Controls.Add(this.label31);
            this.qabul2_panel.Controls.Add(this.label26);
            this.qabul2_panel.Controls.Add(this.vaznitxt2);
            this.qabul2_panel.Controls.Add(this.boyitxt);
            this.qabul2_panel.Controls.Add(this.unvon);
            this.qabul2_panel.Controls.Add(this.yoshtxt2);
            this.qabul2_panel.Controls.Add(this.shariftxt);
            this.qabul2_panel.Controls.Add(this.familiya2txt);
            this.qabul2_panel.Controls.Add(this.ism2txt);
            this.qabul2_panel.Controls.Add(this.guna2DataGridView3);
            this.qabul2_panel.Controls.Add(this.guna2DataGridView2);
            this.qabul2_panel.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.qabul2_panel.Location = new System.Drawing.Point(266, 15);
            this.qabul2_panel.Name = "qabul2_panel";
            this.qabul2_panel.Size = new System.Drawing.Size(1492, 860);
            this.qabul2_panel.TabIndex = 14;
            this.qabul2_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.qabul2_panel_Paint);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1252, 444);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(179, 41);
            this.button2.TabIndex = 75;
            this.button2.Text = "Rasm yuklash";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DodgerBlue;
            this.pictureBox2.Location = new System.Drawing.Point(1249, 230);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(182, 176);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 15;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.White;
            this.guna2Button2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Image = global::Kurs_ishi.Properties.Resources.search;
            this.guna2Button2.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2Button2.Location = new System.Drawing.Point(1112, 582);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(55, 51);
            this.guna2Button2.TabIndex = 72;
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderColor = System.Drawing.Color.Black;
            this.guna2TextBox1.BorderRadius = 10;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(753, 576);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "Qidirish";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(425, 63);
            this.guna2TextBox1.TabIndex = 73;
            this.guna2TextBox1.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // tashxistxt
            // 
            this.tashxistxt.FormattingEnabled = true;
            this.tashxistxt.Items.AddRange(new object[] {
            "Sog\'lom",
            "No sog\'lom"});
            this.tashxistxt.Location = new System.Drawing.Point(375, 674);
            this.tashxistxt.Name = "tashxistxt";
            this.tashxistxt.Size = new System.Drawing.Size(257, 31);
            this.tashxistxt.TabIndex = 62;
            // 
            // xizmat
            // 
            this.xizmat.FormattingEnabled = true;
            this.xizmat.Items.AddRange(new object[] {
            "1 oylik",
            "1 yillik"});
            this.xizmat.Location = new System.Drawing.Point(815, 287);
            this.xizmat.Name = "xizmat";
            this.xizmat.Size = new System.Drawing.Size(301, 31);
            this.xizmat.TabIndex = 63;
            // 
            // kontrakt
            // 
            this.kontrakt.FormattingEnabled = true;
            this.kontrakt.Items.AddRange(new object[] {
            "To\'landi",
            "To\'lanmadi"});
            this.kontrakt.Location = new System.Drawing.Point(815, 339);
            this.kontrakt.Name = "kontrakt";
            this.kontrakt.Size = new System.Drawing.Size(301, 31);
            this.kontrakt.TabIndex = 64;
            this.kontrakt.SelectedIndexChanged += new System.EventHandler(this.kontrakt_SelectedIndexChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(373, 474);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(73, 27);
            this.radioButton3.TabIndex = 58;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Ayol";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(373, 441);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(88, 27);
            this.radioButton4.TabIndex = 57;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Erkak";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(687, 290);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(112, 23);
            this.label27.TabIndex = 70;
            this.label27.Text = "Xizmat turi:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(692, 347);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(94, 23);
            this.label21.TabIndex = 70;
            this.label21.Text = "Kontrakt:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(200, 393);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 23);
            this.label16.TabIndex = 69;
            this.label16.Text = "Sharifi:";
            // 
            // tozabtn2
            // 
            this.tozabtn2.BorderRadius = 10;
            this.tozabtn2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tozabtn2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tozabtn2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tozabtn2.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tozabtn2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tozabtn2.FillColor = System.Drawing.Color.Gold;
            this.tozabtn2.FillColor2 = System.Drawing.Color.Gold;
            this.tozabtn2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.tozabtn2.ForeColor = System.Drawing.Color.White;
            this.tozabtn2.Location = new System.Drawing.Point(978, 712);
            this.tozabtn2.Name = "tozabtn2";
            this.tozabtn2.Size = new System.Drawing.Size(147, 55);
            this.tozabtn2.TabIndex = 70;
            this.tozabtn2.Text = "Tozalash";
            this.tozabtn2.Click += new System.EventHandler(this.tozabtn2_Click);
            // 
            // refbtn
            // 
            this.refbtn.BorderRadius = 10;
            this.refbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.refbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.refbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refbtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.refbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.refbtn.FillColor = System.Drawing.SystemColors.MenuHighlight;
            this.refbtn.FillColor2 = System.Drawing.SystemColors.MenuHighlight;
            this.refbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.refbtn.ForeColor = System.Drawing.Color.White;
            this.refbtn.Location = new System.Drawing.Point(34, 712);
            this.refbtn.Name = "refbtn";
            this.refbtn.Size = new System.Drawing.Size(147, 51);
            this.refbtn.TabIndex = 0;
            this.refbtn.Text = "Yangilash";
            this.refbtn.Click += new System.EventHandler(this.refbtn_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(201, 457);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 23);
            this.label17.TabIndex = 68;
            this.label17.Text = "Jinsi:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(694, 423);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(76, 23);
            this.label28.TabIndex = 65;
            this.label28.Text = "Unvoni:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(204, 527);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 23);
            this.label22.TabIndex = 65;
            this.label22.Text = "Yoshi:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(204, 655);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 23);
            this.label23.TabIndex = 64;
            this.label23.Text = "Tashxis:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(203, 618);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 23);
            this.label20.TabIndex = 71;
            this.label20.Text = "Vazni:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(203, 572);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 23);
            this.label24.TabIndex = 71;
            this.label24.Text = "Bo\'yi:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(201, 342);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(101, 23);
            this.label25.TabIndex = 63;
            this.label25.Text = "Familiyasi:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(201, 290);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 23);
            this.label26.TabIndex = 62;
            this.label26.Text = "Ismi:";
            // 
            // vaznitxt2
            // 
            this.vaznitxt2.Location = new System.Drawing.Point(373, 618);
            this.vaznitxt2.Name = "vaznitxt2";
            this.vaznitxt2.Size = new System.Drawing.Size(259, 30);
            this.vaznitxt2.TabIndex = 61;
            this.vaznitxt2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // boyitxt
            // 
            this.boyitxt.Location = new System.Drawing.Point(373, 572);
            this.boyitxt.Name = "boyitxt";
            this.boyitxt.Size = new System.Drawing.Size(259, 30);
            this.boyitxt.TabIndex = 60;
            this.boyitxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // unvon
            // 
            this.unvon.Location = new System.Drawing.Point(815, 417);
            this.unvon.Name = "unvon";
            this.unvon.Size = new System.Drawing.Size(301, 30);
            this.unvon.TabIndex = 65;
            this.unvon.Text = "Oddiy askar";
            this.unvon.MouseEnter += new System.EventHandler(this.unvon_MouseEnter);
            // 
            // yoshtxt2
            // 
            this.yoshtxt2.Location = new System.Drawing.Point(375, 521);
            this.yoshtxt2.Name = "yoshtxt2";
            this.yoshtxt2.Size = new System.Drawing.Size(257, 30);
            this.yoshtxt2.TabIndex = 59;
            this.yoshtxt2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // shariftxt
            // 
            this.shariftxt.Location = new System.Drawing.Point(371, 389);
            this.shariftxt.Name = "shariftxt";
            this.shariftxt.Size = new System.Drawing.Size(257, 30);
            this.shariftxt.TabIndex = 56;
            // 
            // familiya2txt
            // 
            this.familiya2txt.Location = new System.Drawing.Point(372, 341);
            this.familiya2txt.Name = "familiya2txt";
            this.familiya2txt.Size = new System.Drawing.Size(257, 30);
            this.familiya2txt.TabIndex = 55;
            // 
            // ism2txt
            // 
            this.ism2txt.Location = new System.Drawing.Point(373, 290);
            this.ism2txt.Name = "ism2txt";
            this.ism2txt.Size = new System.Drawing.Size(257, 30);
            this.ism2txt.TabIndex = 54;
            // 
            // guna2DataGridView3
            // 
            this.guna2DataGridView3.AllowUserToAddRows = false;
            this.guna2DataGridView3.AllowUserToDeleteRows = false;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.guna2DataGridView3.ColumnHeadersHeight = 22;
            this.guna2DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView3.DefaultCellStyle = dataGridViewCellStyle24;
            this.guna2DataGridView3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2DataGridView3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.Location = new System.Drawing.Point(0, 574);
            this.guna2DataGridView3.Name = "guna2DataGridView3";
            this.guna2DataGridView3.ReadOnly = true;
            this.guna2DataGridView3.RowHeadersVisible = false;
            this.guna2DataGridView3.RowHeadersWidth = 62;
            this.guna2DataGridView3.RowTemplate.Height = 28;
            this.guna2DataGridView3.Size = new System.Drawing.Size(1492, 286);
            this.guna2DataGridView3.TabIndex = 2;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView3.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView3.ThemeStyle.HeaderStyle.Height = 22;
            this.guna2DataGridView3.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.Height = 28;
            this.guna2DataGridView3.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView3.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView3_CellContentClick);
            // 
            // guna2DataGridView2
            // 
            this.guna2DataGridView2.AllowUserToAddRows = false;
            this.guna2DataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.guna2DataGridView2.AutoGenerateColumns = false;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.guna2DataGridView2.ColumnHeadersHeight = 22;
            this.guna2DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.ismDataGridViewTextBoxColumn1,
            this.Familiya,
            this.sharifDataGridViewTextBoxColumn,
            this.yoshDataGridViewTextBoxColumn,
            this.boyiDataGridViewTextBoxColumn,
            this.vazniDataGridViewTextBoxColumn,
            this.tashxisDataGridViewTextBoxColumn,
            this.xizmatTuriDataGridViewTextBoxColumn});
            this.guna2DataGridView2.DataSource = this.chaqirilganlarBindingSource4;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView2.DefaultCellStyle = dataGridViewCellStyle27;
            this.guna2DataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2DataGridView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.Location = new System.Drawing.Point(0, 0);
            this.guna2DataGridView2.Name = "guna2DataGridView2";
            this.guna2DataGridView2.ReadOnly = true;
            this.guna2DataGridView2.RowHeadersVisible = false;
            this.guna2DataGridView2.RowHeadersWidth = 62;
            this.guna2DataGridView2.RowTemplate.Height = 28;
            this.guna2DataGridView2.Size = new System.Drawing.Size(1492, 247);
            this.guna2DataGridView2.TabIndex = 1;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.Height = 22;
            this.guna2DataGridView2.ThemeStyle.ReadOnly = true;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.Height = 28;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView2_CellContentClick);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.MinimumWidth = 8;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // ismDataGridViewTextBoxColumn1
            // 
            this.ismDataGridViewTextBoxColumn1.DataPropertyName = "Ism";
            this.ismDataGridViewTextBoxColumn1.HeaderText = "Ism";
            this.ismDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.ismDataGridViewTextBoxColumn1.Name = "ismDataGridViewTextBoxColumn1";
            this.ismDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Familiya
            // 
            this.Familiya.DataPropertyName = "Familiya";
            this.Familiya.HeaderText = "Familiya";
            this.Familiya.MinimumWidth = 8;
            this.Familiya.Name = "Familiya";
            this.Familiya.ReadOnly = true;
            // 
            // sharifDataGridViewTextBoxColumn
            // 
            this.sharifDataGridViewTextBoxColumn.DataPropertyName = "Sharif";
            this.sharifDataGridViewTextBoxColumn.HeaderText = "Sharif";
            this.sharifDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.sharifDataGridViewTextBoxColumn.Name = "sharifDataGridViewTextBoxColumn";
            this.sharifDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yoshDataGridViewTextBoxColumn
            // 
            this.yoshDataGridViewTextBoxColumn.DataPropertyName = "Yosh";
            this.yoshDataGridViewTextBoxColumn.HeaderText = "Yosh";
            this.yoshDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.yoshDataGridViewTextBoxColumn.Name = "yoshDataGridViewTextBoxColumn";
            this.yoshDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // boyiDataGridViewTextBoxColumn
            // 
            this.boyiDataGridViewTextBoxColumn.DataPropertyName = "Boyi";
            this.boyiDataGridViewTextBoxColumn.HeaderText = "Boyi";
            this.boyiDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.boyiDataGridViewTextBoxColumn.Name = "boyiDataGridViewTextBoxColumn";
            this.boyiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vazniDataGridViewTextBoxColumn
            // 
            this.vazniDataGridViewTextBoxColumn.DataPropertyName = "Vazni";
            this.vazniDataGridViewTextBoxColumn.HeaderText = "Vazni";
            this.vazniDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vazniDataGridViewTextBoxColumn.Name = "vazniDataGridViewTextBoxColumn";
            this.vazniDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tashxisDataGridViewTextBoxColumn
            // 
            this.tashxisDataGridViewTextBoxColumn.DataPropertyName = "Tashxis";
            this.tashxisDataGridViewTextBoxColumn.HeaderText = "Tashxis";
            this.tashxisDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tashxisDataGridViewTextBoxColumn.Name = "tashxisDataGridViewTextBoxColumn";
            this.tashxisDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // xizmatTuriDataGridViewTextBoxColumn
            // 
            this.xizmatTuriDataGridViewTextBoxColumn.DataPropertyName = "XizmatTuri";
            this.xizmatTuriDataGridViewTextBoxColumn.HeaderText = "XizmatTuri";
            this.xizmatTuriDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.xizmatTuriDataGridViewTextBoxColumn.Name = "xizmatTuriDataGridViewTextBoxColumn";
            this.xizmatTuriDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // chaqirilganlarBindingSource4
            // 
            this.chaqirilganlarBindingSource4.DataMember = "Chaqirilganlar";
            this.chaqirilganlarBindingSource4.DataSource = this.kurs_ishiDataSet7;
            // 
            // kurs_ishiDataSet7
            // 
            this.kurs_ishiDataSet7.DataSetName = "Kurs_ishiDataSet7";
            this.kurs_ishiDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fuqarolarBindingSource1
            // 
            this.fuqarolarBindingSource1.DataMember = "Fuqarolar";
            this.fuqarolarBindingSource1.DataSource = this.kurs_ishiDataSet3;
            // 
            // kurs_ishiDataSet3
            // 
            this.kurs_ishiDataSet3.DataSetName = "Kurs_ishiDataSet3";
            this.kurs_ishiDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // chaqirilganlarBindingSource3
            // 
            this.chaqirilganlarBindingSource3.DataMember = "Chaqirilganlar";
            this.chaqirilganlarBindingSource3.DataSource = this.kurs_ishiDataSet6;
            // 
            // kurs_ishiDataSet6
            // 
            this.kurs_ishiDataSet6.DataSetName = "Kurs_ishiDataSet6";
            this.kurs_ishiDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chaqirilganlarBindingSource1
            // 
            this.chaqirilganlarBindingSource1.DataMember = "Chaqirilganlar";
            this.chaqirilganlarBindingSource1.DataSource = this.kurs_ishiDataSet4;
            // 
            // kurs_ishiDataSet4
            // 
            this.kurs_ishiDataSet4.DataSetName = "Kurs_ishiDataSet4";
            this.kurs_ishiDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sozlamalar_panel
            // 
            this.sozlamalar_panel.BackColor = System.Drawing.Color.White;
            this.sozlamalar_panel.Controls.Add(this.richTextBox1);
            this.sozlamalar_panel.Controls.Add(this.button7);
            this.sozlamalar_panel.Controls.Add(this.button6);
            this.sozlamalar_panel.Controls.Add(this.pictureBox10);
            this.sozlamalar_panel.Controls.Add(this.adminuzpanel);
            this.sozlamalar_panel.Controls.Add(this.guna2Button1);
            this.sozlamalar_panel.Controls.Add(this.label8);
            this.sozlamalar_panel.Controls.Add(this.label30);
            this.sozlamalar_panel.Controls.Add(this.label9);
            this.sozlamalar_panel.Controls.Add(this.kunbtn);
            this.sozlamalar_panel.Controls.Add(this.tunbtn);
            this.sozlamalar_panel.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sozlamalar_panel.Location = new System.Drawing.Point(395, 15);
            this.sozlamalar_panel.Name = "sozlamalar_panel";
            this.sozlamalar_panel.Size = new System.Drawing.Size(13, 972);
            this.sozlamalar_panel.TabIndex = 14;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(65, 706);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(350, 132);
            this.richTextBox1.TabIndex = 55;
            this.richTextBox1.Text = "";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(1056, 209);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(43, 43);
            this.button6.TabIndex = 39;
            this.button6.Text = "-";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(5, 5);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(103, 90);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 38;
            this.pictureBox10.TabStop = false;
            // 
            // adminuzpanel
            // 
            this.adminuzpanel.BackColor = System.Drawing.Color.Transparent;
            this.adminuzpanel.Controls.Add(this.uzgarbtn);
            this.adminuzpanel.Controls.Add(this.button5);
            this.adminuzpanel.Controls.Add(this.label10);
            this.adminuzpanel.Controls.Add(this.label18);
            this.adminuzpanel.Controls.Add(this.label19);
            this.adminuzpanel.Controls.Add(this.textBox3);
            this.adminuzpanel.Controls.Add(this.textBox1);
            this.adminuzpanel.Controls.Add(this.textBox2);
            this.adminuzpanel.Location = new System.Drawing.Point(49, 277);
            this.adminuzpanel.Name = "adminuzpanel";
            this.adminuzpanel.Size = new System.Drawing.Size(599, 334);
            this.adminuzpanel.TabIndex = 37;
            // 
            // uzgarbtn
            // 
            this.uzgarbtn.BorderRadius = 15;
            this.uzgarbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.uzgarbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.uzgarbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.uzgarbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.uzgarbtn.FillColor = System.Drawing.Color.RoyalBlue;
            this.uzgarbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.uzgarbtn.ForeColor = System.Drawing.Color.White;
            this.uzgarbtn.Location = new System.Drawing.Point(235, 255);
            this.uzgarbtn.Name = "uzgarbtn";
            this.uzgarbtn.Size = new System.Drawing.Size(165, 48);
            this.uzgarbtn.TabIndex = 35;
            this.uzgarbtn.Text = "O\'zgartirish";
            this.uzgarbtn.Click += new System.EventHandler(this.uzgarbtn_Click);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(515, 170);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(51, 39);
            this.button5.TabIndex = 39;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button5_MouseDown);
            this.button5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button5_MouseUp);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(45, 118);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 23);
            this.label10.TabIndex = 37;
            this.label10.Text = "Loginingiz";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(44, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 23);
            this.label18.TabIndex = 37;
            this.label18.Text = "Ismingiz:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(45, 175);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 23);
            this.label19.TabIndex = 38;
            this.label19.Text = "Parol";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(201, 118);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(278, 30);
            this.textBox3.TabIndex = 35;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(200, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(278, 30);
            this.textBox1.TabIndex = 35;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(201, 175);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(278, 30);
            this.textBox2.TabIndex = 36;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 15;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.ForestGreen;
            this.guna2Button1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(465, 207);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(162, 44);
            this.guna2Button1.TabIndex = 35;
            this.guna2Button1.Text = "O\'gartirish";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(700, 207);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(350, 32);
            this.label8.TabIndex = 34;
            this.label8.Text = "Asosiy menyuni o\'zgartirish: ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(59, 657);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(301, 32);
            this.label30.TabIndex = 34;
            this.label30.Text = "Bosh adminga murojaat:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(112, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(314, 32);
            this.label9.TabIndex = 34;
            this.label9.Text = "Parollingizni o\'zgartirish:";
            // 
            // kunbtn
            // 
            this.kunbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.kunbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.kunbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.kunbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.kunbtn.FillColor = System.Drawing.Color.Transparent;
            this.kunbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.kunbtn.ForeColor = System.Drawing.Color.White;
            this.kunbtn.Image = global::Kurs_ishi.Properties.Resources.sun;
            this.kunbtn.ImageSize = new System.Drawing.Size(30, 30);
            this.kunbtn.Location = new System.Drawing.Point(19, 921);
            this.kunbtn.Name = "kunbtn";
            this.kunbtn.Size = new System.Drawing.Size(57, 52);
            this.kunbtn.TabIndex = 32;
            this.kunbtn.Click += new System.EventHandler(this.kunbtn_Click);
            // 
            // tunbtn
            // 
            this.tunbtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.tunbtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.tunbtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.tunbtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.tunbtn.FillColor = System.Drawing.Color.Transparent;
            this.tunbtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.tunbtn.ForeColor = System.Drawing.Color.White;
            this.tunbtn.Image = global::Kurs_ishi.Properties.Resources.moon;
            this.tunbtn.ImageSize = new System.Drawing.Size(30, 30);
            this.tunbtn.Location = new System.Drawing.Point(97, 921);
            this.tunbtn.Name = "tunbtn";
            this.tunbtn.Size = new System.Drawing.Size(56, 52);
            this.tunbtn.TabIndex = 33;
            this.tunbtn.Click += new System.EventHandler(this.tunbtn_Click);
            // 
            // kurs_ishiDataSet2
            // 
            this.kurs_ishiDataSet2.DataSetName = "Kurs_ishiDataSet2";
            this.kurs_ishiDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chaqirilganlarBindingSource
            // 
            this.chaqirilganlarBindingSource.DataMember = "Chaqirilganlar";
            this.chaqirilganlarBindingSource.DataSource = this.kurs_ishiDataSet2;
            // 
            // chaqirilganlarTableAdapter
            // 
            this.chaqirilganlarTableAdapter.ClearBeforeFill = true;
            // 
            // fuqarolarTableAdapter1
            // 
            this.fuqarolarTableAdapter1.ClearBeforeFill = true;
            // 
            // chaqirilganlarTableAdapter1
            // 
            this.chaqirilganlarTableAdapter1.ClearBeforeFill = true;
            // 
            // chaqirilganlarTableAdapter3
            // 
            this.chaqirilganlarTableAdapter3.ClearBeforeFill = true;
            // 
            // kurs_ishiDataSet5
            // 
            this.kurs_ishiDataSet5.DataSetName = "Kurs_ishiDataSet5";
            this.kurs_ishiDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chaqirilganlarTableAdapter2
            // 
            this.chaqirilganlarTableAdapter2.ClearBeforeFill = true;
            // 
            // fuqarolarTableAdapter2
            // 
            this.fuqarolarTableAdapter2.ClearBeforeFill = true;
            // 
            // chaqirilganlarBindingSource2
            // 
            this.chaqirilganlarBindingSource2.DataMember = "Chaqirilganlar";
            // 
            // fuqarolarTableAdapter3
            // 
            this.fuqarolarTableAdapter3.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(75, 289);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(106, 31);
            this.comboBox1.TabIndex = 76;
            this.comboBox1.SelectionChangeCommitted += new System.EventHandler(this.comboBox1_SelectionChangeCommitted);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 295);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(38, 23);
            this.label31.TabIndex = 62;
            this.label31.Text = "ID:";
            // 
            // Asosiy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1820, 991);
            this.Controls.Add(this.sozlamalar_panel);
            this.Controls.Add(this.qabul2_panel);
            this.Controls.Add(this.qabul_panel);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Asosiy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asosiy";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Asosiy_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Munebutton)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource)).EndInit();
            this.qabul_panel.ResumeLayout(false);
            this.qabul_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet8)).EndInit();
            this.qabul2_panel.ResumeLayout(false);
            this.qabul2_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuqarolarBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet4)).EndInit();
            this.sozlamalar_panel.ResumeLayout(false);
            this.sozlamalar_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.adminuzpanel.ResumeLayout(false);
            this.adminuzpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kurs_ishiDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaqirilganlarBindingSource2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer menuTimer;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Munebutton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button settingsbtn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button helpbtn;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button aboutbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource fuqarolarBindingSource;
        private System.Windows.Forms.Panel qabul_panel;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox birthtxt;
        private System.Windows.Forms.ComboBox millattxt;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.TextBox telefontxt;
        private System.Windows.Forms.TextBox kasbtxt;
        private System.Windows.Forms.TextBox familiyatxt;
        private System.Windows.Forms.TextBox ismitxt;
        private System.Windows.Forms.RichTextBox manziltxt;
        private Guna.UI2.WinForms.Guna2Button deletebtn;
        private Guna.UI2.WinForms.Guna2Button editbtn;
        private Guna.UI2.WinForms.Guna2Button savebtn;
        private System.Windows.Forms.TextBox yoshtxt;
        private Guna.UI2.WinForms.Guna2Button tozabtn;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button button4;
        private Guna.UI2.WinForms.Guna2Button refreshbtn;
        private Guna.UI2.WinForms.Guna2TextBox qidirtxt;
        private Guna.UI2.WinForms.Guna2Button qidirbtn;
        private System.Windows.Forms.ToolTip toolTip1;
        private Guna.UI2.WinForms.Guna2Button printbtn;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Guna.UI2.WinForms.Guna2Panel qabul2_panel;
        private Guna.UI2.WinForms.Guna2GradientButton qushbtn;
        private Guna.UI2.WinForms.Guna2Panel sozlamalar_panel;
        private Guna.UI2.WinForms.Guna2Button kunbtn;
        private Guna.UI2.WinForms.Guna2Button tunbtn;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel adminuzpanel;
        private Guna.UI2.WinForms.Guna2Button uzgarbtn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox3;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView2;
        private Kurs_ishiDataSet2 kurs_ishiDataSet2;
        private System.Windows.Forms.BindingSource chaqirilganlarBindingSource;
        private Kurs_ishiDataSet2TableAdapters.ChaqirilganlarTableAdapter chaqirilganlarTableAdapter;
        private Kurs_ishiDataSet3 kurs_ishiDataSet3;
        private System.Windows.Forms.BindingSource fuqarolarBindingSource1;
        private Kurs_ishiDataSet3TableAdapters.FuqarolarTableAdapter fuqarolarTableAdapter1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView3;
        private Kurs_ishiDataSet4 kurs_ishiDataSet4;
        private System.Windows.Forms.BindingSource chaqirilganlarBindingSource1;
        private Kurs_ishiDataSet4TableAdapters.ChaqirilganlarTableAdapter chaqirilganlarTableAdapter1;
        private System.Windows.Forms.Button rasmbtn;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox boyitxt;
        private System.Windows.Forms.TextBox yoshtxt2;
        private System.Windows.Forms.TextBox shariftxt;
        private System.Windows.Forms.TextBox familiya2txt;
        private System.Windows.Forms.TextBox ism2txt;
        private System.Windows.Forms.BindingSource chaqirilganlarBindingSource2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox vaznitxt2;
        private Kurs_ishiDataSet6 kurs_ishiDataSet6;
        private System.Windows.Forms.BindingSource chaqirilganlarBindingSource3;
        private Kurs_ishiDataSet6TableAdapters.ChaqirilganlarTableAdapter chaqirilganlarTableAdapter3;
        private System.Windows.Forms.ComboBox xizmat;
        private System.Windows.Forms.ComboBox kontrakt;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox unvon;
        private Guna.UI2.WinForms.Guna2GradientButton delbtn;
        private Guna.UI2.WinForms.Guna2GradientButton tahrirbtn;
        private Guna.UI2.WinForms.Guna2Button printbtn2;
        private Kurs_ishiDataSet5 kurs_ishiDataSet5;
        private Kurs_ishiDataSet7 kurs_ishiDataSet7;
        private System.Windows.Forms.BindingSource chaqirilganlarBindingSource4;
        private Kurs_ishiDataSet7TableAdapters.ChaqirilganlarTableAdapter chaqirilganlarTableAdapter2;
        private Guna.UI2.WinForms.Guna2GradientButton refbtn;
        private Guna.UI2.WinForms.Guna2GradientButton tozabtn2;
        private System.Windows.Forms.ComboBox tashxistxt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn ismDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Familiya;
        private System.Windows.Forms.DataGridViewTextBoxColumn sharifDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yoshDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn boyiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vazniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tashxisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn xizmatTuriDataGridViewTextBoxColumn;
        private Kurs_ishiDataSet8 kurs_ishiDataSet8;
        private System.Windows.Forms.BindingSource fuqarolarBindingSource2;
        private Kurs_ishiDataSet8TableAdapters.FuqarolarTableAdapter fuqarolarTableAdapter2;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label datalbl;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox shariftxt1;
        private Kurs_ishiDataSet11 kurs_ishiDataSet11;
        private System.Windows.Forms.BindingSource fuqarolarBindingSource3;
        private Kurs_ishiDataSet11TableAdapters.FuqarolarTableAdapter fuqarolarTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ismDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sharifiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yoshiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kasbiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jinsiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn millatiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manziliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn joindateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label31;
    }
}