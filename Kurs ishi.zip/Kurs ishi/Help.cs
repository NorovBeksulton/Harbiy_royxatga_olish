﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kurs_ishi
{
    public partial class Help : Form
    {
        public Help()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Process.Start("https://mail.google.com/mail/u/0/?tab=rm&ogbl#search/in%3Asent+norovbeksulton72%40gmail.com");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Process.Start("https://t.me/Bek_481_22");
        }
    }
}
