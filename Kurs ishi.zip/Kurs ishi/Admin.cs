﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace Kurs_ishi
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kurs_ishiDataSet.Login' table. You can move, or remove it, as needed.
            this.loginTableAdapter.Fill(this.kurs_ishiDataSet.Login);

            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kurs"].ConnectionString);

            con.Open();
            adminuzpanel.Visible = false;
            admintekpanel.Visible = false;
        }

        private void guna2DataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 3 && e.Value != null)
            {
                e.Value = new string('*', e.Value.ToString().Length);
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        SqlConnection con;

        private void uchirishbtn_Click(object sender, EventArgs e)
        {
           
            SqlCommand cmd = new SqlCommand($"delete from Login where Id={guna2DataGridView1.SelectedRows[0].Cells[0].Value}", con);

            MessageBox.Show("Muvafaqiyatli " + cmd.ExecuteNonQuery().ToString() + " ta o'chirildi! ");
            SqlDataAdapter da = new SqlDataAdapter("select * from Login", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }
        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Login", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataView dv = dt.DefaultView;
            dv.RowFilter = string.Format("Ism LIKE '%{0}%'", guna2TextBox1.Text);
            guna2DataGridView1.DataSource = dv.ToTable();
        }

        private void guna2Button2_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(kirishbtn, "Dasturga o'tish uchun bosing");
        }

        private void kirishbtn_Click(object sender, EventArgs e)
        {
            Asosiy asosiy = new Asosiy();
            asosiy.ShowDialog();
            this.Close();
        }

        private void chiqishbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tasdiqbtn_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter(
            "select count(*) from Admin where Login='" + adminlogin.Text + "' and Parol='" + adminparol.Text + "'", con);
            DataTable dat = new DataTable();
            da.Fill(dat);
            if (adminlogin.Text == string.Empty || adminparol.Text == string.Empty)
            {
                MessageBox.Show("Login yoki parolni kiriting!");
            }
            else
            {
                if (dat.Rows[0][0].ToString() == "1")
                {
                    adminuzpanel.Visible = true;
                    admintekpanel.Visible = false;
                    adminlogin.Clear();
                    adminparol.Clear();
                }
                else
                {
                    MessageBox.Show("Login yoki Parolni to'g'ri kiriting!");
                }

            }
        }

        private void refreshbtn_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Yangi Login yoki parolingizni kiriting!");
            }
            else
            {
                SqlCommand cmd = new SqlCommand($"update Admin set Login=@Login,Parol=@Parol", con);
                cmd.Parameters.AddWithValue("Login", textBox1.Text);
                cmd.Parameters.AddWithValue("Parol", textBox2.Text);
                cmd.ExecuteNonQuery().ToString();
                MessageBox.Show("Login va Parollingiz o'zgartirildi!");
                adminuzpanel.Visible=false;
                admintekpanel.Visible=false;
                textBox1.Clear();
                textBox2.Clear();

            }
           
        }

        private void eyebtn_MouseDown(object sender, MouseEventArgs e)
        {
            adminparol.PasswordChar = '\0';
        }

        private void eyebtn_MouseUp(object sender, MouseEventArgs e)
        {
            adminparol.PasswordChar = '*';
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '\0';
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            admintekpanel.Visible = true;

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void kunbtn_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            admin.BackColor = Color.White;
            admin.ForeColor = Color.Black;
            tabPage1.ForeColor = Color.Black;
            tabPage1.BackColor= Color.White;
            tabPage4.ForeColor = Color.Black;
            tabPage4.BackColor= Color.White;
        }

        private void tunbtn_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            admin.BackColor = Color.Gray;
            admin.ForeColor = Color.White;
            tabPage1.ForeColor = Color.White;
            tabPage1.BackColor = Color.Gray;
            tabPage4.ForeColor = Color.White;
            tabPage4.BackColor = Color.Gray;
        }

        private void chiqbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void kirbtn_Click(object sender, EventArgs e)
        {
            Asosiy asosiy = new Asosiy();
            asosiy.ShowDialog();
            this.Close();
        }

        private void chiqishbtn_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(chiqishbtn, "Dasturda chiqish uchun bosing");
        }

        private void kirbtn_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(kirbtn, "Dasturga kirish uchun bosing");
        }

        private void chiqbtn_MouseEnter(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(chiqbtn, "Dasturda chiqish uchun bosing");
        }

        private void eyebtn_Click(object sender, EventArgs e)
        {

        }
    }
}
